# 第四題：粉料秤重控制系統 — 三菱 ST 程式

- 平台：MELSEC iQ-F (FX5U) / GX Works3
- 語言：ST (Structured Text)
- 重量單位：全部以 0.1 kg 為 1 的整數計算（150.9 kg = 1509）

## 使用說明

1. 先依程式開頭的「標籤與軟元件對照表」建立全域標籤，其中停電保持標籤要設為 Retain。
2. 建立兩個使用者函數 `Bcd4ToInt`、`Int2Bcd4`，內容為程式中 FUN 1、FUN 2 區段。
3. 建立主程式，內容為「主程式」區段。
4. FX3U (GX Works2) 需將 RTC 改為 D8013~D8016，計時器改寫為 `OUT_T`。

## 本次修訂（依規格書「動作程序表」逐步核對）

| # | 位置 | 規格依據 | 修改內容 |
|---|------|----------|----------|
| 1 | `T_Wait3` | 程序表 參(1) 步驟 8~10、參(2) 步驟 13~14：閘門未關妥時不執行；「閘門關(LS-G 動作)」後才計時 3 秒 | 原本進入 WAIT3 即開始計時，閘門晚關會直接跳過 3 秒。改為 `State = ST_WAIT3 AND Gate_Closed` 才計時（閘門中途打開則歸零重計）。 |
| 2 | `T_Wait10` | 程序表 參(2) 步驟 17：「閘門關(LS-G 動作)，完成第一周期計量操作」後計時 10 秒，期間按 PB1 無效 | 同上，改為 `State = ST_WAIT10 AND Gate_Closed` 才計時。 |
| 3 | 切斷值運算 | 規格 3.(3)：切斷值＝設定值－補償值，顯示一位小數 | 原本補償值先無條件捨去再相減（150.9kg、×0.2 → 顯示 120.8）；改為直接算 設定值×(1－補償率) 並四捨五入到 0.1kg（→ 120.7，與手算 120.72 一致）。 |

其餘部分（手動／自動流程、補償率、緊急停止、BZ 斷續響、PL3、停電 5 秒判斷、殘料 15 秒排除）逐項對照程序表壹～伍，邏輯與規格相符，未更動。

## 完整程式碼

```pascal
(*==========================================================================
  第四題：粉料秤重控制系統
  三菱 MELSEC iQ-F (FX5U) / GX Works3  ST 語言
  --------------------------------------------------------------------------
  一、標籤(Label)與軟元件對照表  ※ 於 GX Works3 全域標籤中建立
  --------------------------------------------------------------------------
  【輸入】
   LT1_Full    BOOL  X0   COS1  LT1 (ON=位置1=滿位, OFF=位置2=空位)
   LT2_Full    BOOL  X1   COS2  LT2 (同上)
   LT3_Full    BOOL  X2   COS3  LT3 (同上)
   COS4_Man    BOOL  X3   COS4 切於 1：手動
   COS4_Auto   BOOL  X4   COS4 切於 2：自動 (兩者皆 OFF = 位置0 BZ停)
   LS_G        BOOL  X5   COS5 模擬 LS-G (ON=閘門關閉/LS-G 動作)
   PB1_Auto    BOOL  X6   PB1 自動計量
   PB2_Man     BOOL  X7   PB2 手動計量
   PB3_Disch   BOOL  X10  PB3 手動出料
   PB4_EMS     BOOL  X11  PB4 緊急停止 (1b 接點：平時 ON，按下 OFF)
   SW_Set      WORD  K4X20 (X20~X37) 4 位 BCD 指撥開關 (例 1509 = 150.9kg)
  【輸出】
   MC1         BOOL  Y0   下料電動機 M1
   MC2         BOOL  Y1   氣壓缸 / 出料閘門
   PL1         BOOL  Y2   下料中
   PL2         BOOL  Y3   出料中
   PL3         BOOL  Y4   警報
   BZ          BOOL  Y5   蜂鳴器
   DISP_Wt     WORD  K4Y20 (Y20~Y37) 計量值七段顯示 (BCD，小數點硬接於第 1 位)
   DISP_Cut    WORD  K4Y40 (Y40~Y57) 切斷值七段顯示 (BCD)
  【資料】
   Wt_Raw      INT   D100  傳感器串列通訊(MODBUS RTU 等)讀入之重量原始值
   RTC_Day     INT   SD212 \
   RTC_Hour    INT   SD213  | FX5U 內建時鐘 (日/時/分/秒)
   RTC_Min     INT   SD214  |
   RTC_Sec     INT   SD215 /
   First_Scan  BOOL  SM402 RUN 後第一個掃描 ON
  【停電保持(Retain)標籤】
   Ret_Drain   BOOL  (停電前出料閘門是否開啟)
   Ret_DlyMode BOOL  (停電前出料是否為「歸零後延時 5 秒」模式)
   Ret_Ts      DINT  (停電前最後掃描時間，單位：秒)
  【常數 Constant】
   RAW_FS      DINT  2000   Wt_Raw 滿刻度(200.0kg)對應原始值，依傳感器實際調整
   ST_IDLE=0  ST_FILL=10  ST_SETTLE=20  ST_DRAIN=30  ST_WAIT3=40  ST_WAIT10=50
  【區域標籤】
   State, Batch_Cnt, Wt_x10, Sp_x10, Cut_x10, Comp_x10, Comp_pct : INT
   Now_s, Outage : DINT
   Emg_Active, Mode_Man, Mode_Auto, Cos4_Zero, Sp_Valid, Wt_Zero, Cut_Reach,
   Gate_Closed, Auto_Ready, Manual_Run, Drain_Dly, Batch_Drain, Need_PB3 : BOOL
   T_Resid, T_Settle, T_Close, T_Wait3, T_Wait10, T_Blk1, T_Blk2 : TON
   R_Pb1, R_Pb3 : R_TRIG

  重量單位：全部以 0.1 kg 為 1 (整數)，例 150.9kg = 1509
==========================================================================*)


(*==========================================================================
  FUN 1：Bcd4ToInt   (BCD 轉整數)   回傳 INT
  VAR_INPUT  W : WORD;
==========================================================================*)
Bcd4ToInt := WORD_TO_INT(SHR(W, 12) AND 16#000F) * 1000
           + WORD_TO_INT(SHR(W,  8) AND 16#000F) * 100
           + WORD_TO_INT(SHR(W,  4) AND 16#000F) * 10
           + WORD_TO_INT(W AND 16#000F);


(*==========================================================================
  FUN 2：Int2Bcd4   (整數轉 BCD)    回傳 WORD
  VAR_INPUT  V : INT;     VAR  D3, D2, D1, D0, T : INT;
==========================================================================*)
T  := MIN(MAX(V, 0), 9999);
D3 := T / 1000;   T := T MOD 1000;
D2 := T / 100;    T := T MOD 100;
D1 := T / 10;
D0 := T MOD 10;
Int2Bcd4 := SHL(INT_TO_WORD(D3), 12) OR SHL(INT_TO_WORD(D2), 8)
         OR SHL(INT_TO_WORD(D1), 4)  OR INT_TO_WORD(D0);


(*==========================================================================
  主程式 (Program，每掃描執行)
==========================================================================*)

(*---------------- 1. 輸入處理 ----------------*)
Emg_Active  := NOT PB4_EMS;                                  // 1b 接點，按下=動作
Mode_Man    := COS4_Man  AND NOT COS4_Auto;
Mode_Auto   := COS4_Auto AND NOT COS4_Man;
Cos4_Zero   := NOT COS4_Man AND NOT COS4_Auto;               // COS4 於 0 位置
Gate_Closed := LS_G;                                         // LS-G 動作 = 閘門關閉

R_Pb1(CLK := PB1_Auto);
R_Pb3(CLK := PB3_Disch);

(*---------------- 2. 重量換算 (0.0~200.0kg → 0~2000) ----------------*)
Wt_x10 := DINT_TO_INT( MIN( MAX( INT_TO_DINT(Wt_Raw) * 2000 / RAW_FS, 0 ), 2000 ) );
Wt_Zero := (Wt_x10 <= 0);                                    // 計量值顯示為零

(*---------------- 3. 設定值、補償值、切斷值 ----------------*)
Sp_x10   := Bcd4ToInt(SW_Set);                               // 設定值 (65.0~150.9)
Sp_Valid := (Sp_x10 >= 650) AND (Sp_x10 <= 1509);

IF LT1_Full THEN                                             // 達 LT1：×0.2
    Comp_pct := 20;
ELSIF LT2_Full THEN                                          // 達 LT2：×0.12
    Comp_pct := 12;
ELSIF LT3_Full THEN                                          // 達 LT3：×0.06
    Comp_pct := 6;
ELSE                                                         // 低於 LT3：×0
    Comp_pct := 0;
END_IF;

// 切斷值 = 設定值 - 補償值 = 設定值 × (1 - 補償率)，於 0.1kg 位數四捨五入
// 例：150.9kg、LT1 滿位 → 150.9×0.8 = 120.72 → 120.7 (1207)
Cut_x10   := DINT_TO_INT( (INT_TO_DINT(Sp_x10) * INT_TO_DINT(100 - Comp_pct) + 50) / 100 );
Comp_x10  := Sp_x10 - Cut_x10;                               // 補償值 (僅供監視)
Cut_Reach := (Wt_x10 >= Cut_x10);

(*---------------- 4. 時間 (RTC 秒數) 供停電時間判斷 ----------------*)
Now_s := INT_TO_DINT(RTC_Day)  * 86400
       + INT_TO_DINT(RTC_Hour) * 3600
       + INT_TO_DINT(RTC_Min)  * 60
       + INT_TO_DINT(RTC_Sec);

(*---------------- 5. 送電第一掃描：停電復電處理 ----------------*)
IF First_Scan THEN
    State       := ST_IDLE;
    Batch_Cnt   := 0;
    Drain_Dly   := FALSE;
    Batch_Drain := FALSE;
    Need_PB3    := FALSE;

    IF Ret_Drain AND (NOT Emg_Active) THEN                   // 停電時正在出料
        Outage := Now_s - Ret_Ts;
        IF (Outage >= 0) AND (Outage <= 5) THEN              // 5 秒內復電：繼續出料
            Drain_Dly := Ret_DlyMode;
            State     := ST_DRAIN;
        ELSE                                                 // 超過 5 秒：須按 PB3 排料
            Need_PB3 := TRUE;
        END_IF;
    END_IF;
END_IF;

(*---------------- 6. 計時器 (依目前狀態驅動) ----------------*)
T_Resid (IN := Mode_Auto AND (State = ST_IDLE) AND (NOT Wt_Zero)
               AND (NOT Need_PB3) AND (NOT Emg_Active),  PT := T#15s);  // 送電後殘料15秒
T_Settle(IN := (State = ST_SETTLE),                      PT := T#5s);   // 停止下料後5秒
T_Close (IN := (State = ST_DRAIN) AND Drain_Dly AND Wt_Zero,
                                                         PT := T#5s);   // 歸零後5秒關閘
T_Wait3 (IN := (State = ST_WAIT3)  AND Gate_Closed,      PT := T#3s);   // 閘門關(LS-G動作)後3秒
T_Wait10(IN := (State = ST_WAIT10) AND Gate_Closed,      PT := T#10s);  // 閘門關(LS-G動作)後10秒

(*---------------- 7. 自動準備條件 ----------------*)
Auto_Ready := Mode_Auto AND LT2_Full AND Wt_Zero AND Gate_Closed
              AND Sp_Valid AND (NOT Need_PB3) AND (NOT Emg_Active);

(*---------------- 8. 主控制流程 ----------------*)
IF Emg_Active THEN
    // 緊急停止：M1 停、閘門關，流程回到送電後初始狀態
    State       := ST_IDLE;
    Batch_Cnt   := 0;
    Drain_Dly   := FALSE;
    Batch_Drain := FALSE;
    Need_PB3    := FALSE;
ELSE
    CASE State OF

    ST_IDLE:
        IF R_Pb3.Q AND ((Mode_Man AND LT3_Full) OR Need_PB3) THEN
            // 手動出料 / 停電超過5秒復電後排料：歸零後延時5秒關閘
            Drain_Dly   := TRUE;
            Batch_Drain := FALSE;
            State       := ST_DRAIN;
        ELSIF R_Pb1.Q AND Auto_Ready THEN
            // 自動計量開始
            Batch_Cnt := 0;
            State     := ST_FILL;
        ELSIF T_Resid.Q THEN
            // 自動模式：送電後 15 秒自動排除殘料，歸零即關閘
            Drain_Dly   := FALSE;
            Batch_Drain := FALSE;
            State       := ST_DRAIN;
        END_IF;

    ST_FILL:                                                  // 下料中 (MC1/PL1 ON)
        IF NOT Mode_Auto THEN
            State     := ST_IDLE;
            Batch_Cnt := 0;
        ELSIF Cut_Reach THEN                                  // 計量值達切斷值
            State := ST_SETTLE;
        END_IF;

    ST_SETTLE:                                                // M1 停止，等待 5 秒
        IF NOT Mode_Auto THEN
            State     := ST_IDLE;
            Batch_Cnt := 0;
        ELSIF T_Settle.Q THEN
            Drain_Dly   := FALSE;
            Batch_Drain := TRUE;
            State       := ST_DRAIN;
        END_IF;

    ST_DRAIN:                                                 // 出料中 (MC2/PL2 ON)
        IF Wt_Zero AND ((NOT Drain_Dly) OR T_Close.Q) THEN
            Need_PB3 := FALSE;
            IF Batch_Drain THEN
                Batch_Cnt := Batch_Cnt + 1;
                IF Batch_Cnt >= 3 THEN
                    State := ST_WAIT10;                       // 三次完成
                ELSE
                    State := ST_WAIT3;                        // 下一批
                END_IF;
            ELSE
                State := ST_IDLE;
            END_IF;
            Drain_Dly   := FALSE;
            Batch_Drain := FALSE;
        END_IF;

    ST_WAIT3:                                                 // LS-G 動作後等待 3 秒 (閘門未關妥則不計時)
        IF NOT Mode_Auto THEN
            State     := ST_IDLE;
            Batch_Cnt := 0;
        ELSIF T_Wait3.Q AND LT2_Full AND Gate_Closed AND Sp_Valid THEN
            State := ST_FILL;
        END_IF;

    ST_WAIT10:                                                // 三批後 LS-G 動作再等 10 秒 (期間按 PB1 無效)
        IF T_Wait10.Q OR (NOT Mode_Auto) THEN
            Batch_Cnt := 0;
            State     := ST_IDLE;                             // 可再按 PB1 開始新週期
        END_IF;

    ELSE
        State := ST_IDLE;
    END_CASE;
END_IF;

(*---------------- 9. 輸出 ----------------*)
// 手動計量：按住 PB2 下料，達切斷值或放開即停
Manual_Run := Mode_Man AND LT3_Full AND PB2_Man AND (NOT Cut_Reach)
              AND Gate_Closed AND Sp_Valid AND (State = ST_IDLE);

MC1 := ((State = ST_FILL) OR Manual_Run) AND (NOT Emg_Active);
MC2 := (State = ST_DRAIN) AND (NOT Emg_Active);
PL1 := MC1;
PL2 := MC2;

(*---------------- 10. 緊急停止警報 ----------------*)
// BZ 斷續響 (ON 0.5s / OFF 0.5s)；COS4 切至 0 → BZ 停、PL3 亮；EMS 復歸 → PL3 熄
T_Blk1(IN := Emg_Active AND (NOT Cos4_Zero) AND (NOT T_Blk2.Q), PT := T#500ms);
T_Blk2(IN := T_Blk1.Q,                                          PT := T#500ms);

BZ  := Emg_Active AND (NOT Cos4_Zero) AND (NOT T_Blk1.Q);
PL3 := Emg_Active AND Cos4_Zero;

(*---------------- 11. 顯示 ----------------*)
DISP_Wt  := Int2Bcd4(Wt_x10);                                // 計量值 (XXX.X)
DISP_Cut := Int2Bcd4(Cut_x10);                               // 切斷值 (XXX.X)

(*---------------- 12. 停電保持資料更新 ----------------*)
Ret_Drain   := MC2;
Ret_DlyMode := Drain_Dly;
Ret_Ts      := Now_s;
```
