# 第五題 自動門開閉控制 — 三菱 MELSEC ST 程式

FBs-40MCR2-AC


```pascal
(*==========================================================================
  第五題 自動門開閉控制 -- 三菱 MELSEC ST (GX Works3 / iQ-F FX5U 語法)
  ----------------------------------------------------------------------
  【全域標籤 Global Label  (Class=VAR_GLOBAL, 指定裝置)】
   輸入 (BOOL)                      輸出 (BOOL)
   LS1     X0   全開限制開關         MC1  Y0   電動機正轉(開門)
   LS2     X1   全閉限制開關         MC2  Y1   電動機反轉(關門)
   PB1     X2   開門按鈕 (NO)        PL1  Y2   全開/開門運轉燈
   PB2     X3   關門按鈕 (NO)        PL2  Y3   全閉/關門運轉燈
   PB3     X4   警報復歸按鈕 (NO)    PL3  Y4   自動關門指示燈
   COS1    X5   手動關門位置         PL4  Y5   過載警報燈
   COS2    X6   自動關門位置         BZ   Y6   蜂鳴器
   TH_OK   X7   積熱電驛 b 接點 (正常ON, 跳脫/斷線=OFF)
   IR      X10  紅外線感測器 (偵測到人/物=ON)
   MC1_FB  X11  MC1 輔助 a 接點 (線圈動作回授)
   MC2_FB  X12  MC2 輔助 a 接點 (線圈動作回授)
   (MC1/MC2 外部連鎖: MC1 線圈串 MC2 b 接點, MC2 線圈串 MC1 b 接點)

  【區域標籤 Local Label】(請用「非保持(非 Latch)」記憶體, 斷電重啟即清除)
   stState                 : INT    狀態 0=停止 1=開門 2=關門 3=反轉等待2秒
   bFlk, bWarnAct, bBlock  : BOOL
   bAlm, bSil, bSaf        : BOOL   過載警報 / 已按PB3消音 / 安全防護(IR)
   bFault, bBootTh         : BOOL   輸出確認異常 / 開機時TH未復歸
   bPB1p, bPB2p, bPB3p     : BOOL   按鈕上緣脈波
   bPB1_old, bPB2_old, bPB3_old : BOOL
   bRun                    : BOOL
   tFlkOn, tFlkOff, tWarn, tRev, tFbErr : TON  (標準計時器功能方塊)

  【v2 修改紀錄 (對照規格書及評分表)】
   1. PL4: 改為「已按PB3 且 TH 仍未復歸」才閃爍; TH 復歸即熄 (評分表 玖-11)。
   2. 新增 RUN 後第一掃描初始化, 清除 狀態/警報/防護/輸出異常/開機TH旗標,
      確保「重新啟動 PLC」必定回到初始狀態 (規定六-5-(2)、評分表 拾壹/拾貳)。
   其餘動作邏輯逐項比對規格 貳~六 及評分表 壹~拾貳, 與規格一致, 未更動。

  【設計假設】
   1. PL1/PL2「運轉指示」不直接用 PLC 輸出 Y0/Y1 判斷, 改用 MC1/MC2 輔助接點回授
      (X11/X12) 作為閃爍條件 (規定六-1)。
   2. SM402 = RUN 後僅 ON 一個掃描 (iQ-F/iQ-R)。若為 FX3U 請改 M8002。
==========================================================================*)

(* ---------- 0. 閃爍產生器 ON 0.5s / OFF 0.5s ---------- *)
tFlkOn (IN := NOT tFlkOff.Q, PT := T#500ms);
tFlkOff(IN := tFlkOn.Q,      PT := T#500ms);
bFlk := tFlkOn.Q;

(* ---------- 1. 按鈕上緣脈波 ---------- *)
bPB1p := PB1 AND NOT bPB1_old;   bPB1_old := PB1;
bPB2p := PB2 AND NOT bPB2_old;   bPB2_old := PB2;
bPB3p := PB3 AND NOT bPB3_old;   bPB3_old := PB3;

(* ---------- 1-1. 初始化 (規定六-5-(2): 重新啟動 PLC 恢復初始狀態) ---------- *)
(* 不依賴 STOP->RUN 時非保持記憶體是否被清除, RUN 後第一個掃描明確清除 *)
IF SM402 THEN
    stState := 0;
    bAlm := FALSE;  bSil := FALSE;  bSaf := FALSE;
    bFault := FALSE;  bBootTh := FALSE;
END_IF;

(* ---------- 2. 開機TH檢查 / 輸出確認 (規定六-3,4,5) ---------- *)
(* 開機時積熱電驛未復歸: BZ 斷續響, 燈全滅, 無法操作; 復歸後才恢復 *)
IF SM402 AND (NOT TH_OK) THEN
    bBootTh := TRUE;
END_IF;
IF TH_OK THEN
    bBootTh := FALSE;
END_IF;

(* MC 線圈與 PLC 輸出不同步超過 0.5 秒 -> 異常鎖定, 需斷電重啟才解除 *)
tFbErr(IN := ((MC1 <> MC1_FB) OR (MC2 <> MC2_FB)), PT := T#500ms);
IF tFbErr.Q THEN
    bFault := TRUE;
END_IF;

bBlock := bFault OR bBootTh;

(* ---------- 3. 過載警報 / 安全防護鎖定 ---------- *)
bRun := MC1 OR MC2;

(* 運轉中 TH 跳脫(或回路斷線) -> 警報鎖定; 馬達未運轉時 TH 跳脫無作用 *)
IF (NOT TH_OK) AND bRun THEN
    bAlm := TRUE;
END_IF;
IF bAlm AND bPB3p THEN
    bSil := TRUE;                       (* PB3: BZ 停響, PL4 閃爍 *)
END_IF;
IF bAlm AND LS1 AND TH_OK THEN          (* 全開 且 TH 復歸 -> 恢復正常 *)
    bAlm := FALSE;
    bSil := FALSE;
END_IF;

(* 關門中 IR 動作 -> 安全防護鎖定 (BZ 持續響) *)
IF (stState = 2) AND IR THEN
    bSaf := TRUE;
END_IF;
IF bSaf AND LS1 AND (NOT IR) THEN       (* 全開 且 IR 離開 -> 恢復正常 *)
    bSaf := FALSE;
END_IF;

(* ---------- 4. 自動關門預告計時 (全開、自動、閒置) ---------- *)
bWarnAct := (stState = 0) AND LS1 AND COS2
            AND (NOT bAlm) AND (NOT bSaf) AND (NOT bBlock);
tWarn(IN := bWarnAct, PT := T#10s);     (* PL3 閃爍 10 次 *)

(* ---------- 5. 關門中 PB1 -> 停止 2 秒再開門 ---------- *)
tRev(IN := (stState = 3), PT := T#2s);

(* ---------- 6. 主狀態機 ---------- *)
IF bBlock THEN
    stState := 0;
ELSE
    CASE stState OF

    0:  (* 停止 *)
        IF NOT (bAlm OR bSaf) THEN
            IF bPB1p AND (NOT LS1) THEN          (* 全閉或中途 -> 開門 *)
                stState := 1;
            ELSIF bPB2p AND (NOT LS2) THEN       (* 全開或中途 -> 關門; 預告期間按PB2立即關門 *)
                stState := 2;
            ELSIF tWarn.Q THEN                   (* 預告10秒到 -> 自動關門 *)
                stState := 2;
            END_IF;
        END_IF;

    1:  (* 開門中: 到 LS1 停止; TH跳脫仍繼續開到全開 *)
        IF LS1 THEN
            stState := 0;
        END_IF;

    2:  (* 關門中 *)
        IF bAlm OR bSaf THEN                     (* TH跳脫 / IR動作 -> 立即改開門 *)
            stState := 1;
        ELSIF bPB1p THEN                         (* PB1 -> 立即停止, 等2秒 *)
            stState := 3;
        ELSIF LS2 THEN                           (* 到 LS2 停止 *)
            stState := 0;
        END_IF;

    3:  (* 反轉等待 2 秒後開門 *)
        IF tRev.Q THEN
            stState := 1;
        END_IF;

    ELSE
        stState := 0;
    END_CASE;
END_IF;

(* ---------- 7. 輸出 ---------- *)
MC1 := (stState = 1) AND (NOT bBlock);
MC2 := (stState = 2) AND (NOT bBlock);

(* PL1: 開門中(MC1回授)閃爍 / 全開恆亮 *)
PL1 := (NOT bBlock) AND ((MC1_FB AND bFlk) OR (LS1 AND (NOT MC1_FB)));
(* PL2: 關門中(MC2回授)閃爍 / 全閉恆亮 *)
PL2 := (NOT bBlock) AND ((MC2_FB AND bFlk) OR (LS2 AND (NOT MC2_FB)));
(* PL3: 自動模式恆亮; 預告關門期間閃爍 *)
PL3 := (NOT bBlock) AND COS2 AND ((NOT bWarnAct) OR bFlk);
(* PL4: 過載警報已按PB3 -> 閃爍 *)
(* 依評分表 玖-10/11、捌-7/8: 按PB3後閃爍, 只要TH一復歸 PL4 立即熄 (不必等到全開) *)
PL4 := (NOT bBlock) AND bAlm AND bSil AND (NOT TH_OK) AND bFlk;
(* BZ: 開機TH未復歸=斷續響; 過載(未消音)/IR防護=連續響; 輸出異常=全OFF *)
BZ  := (NOT bFault) AND
       ( (bBootTh AND bFlk)
         OR ((NOT bBootTh) AND ((bAlm AND (NOT bSil)) OR bSaf)) );
```
