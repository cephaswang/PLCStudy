# 第三題：多段行程教導運轉定位與顯示控制 — 三菱 ST 程式

- 平台：MELSEC iQ-F (FX5U) / GX Works3，語言：ST (Structured Text)
- 依據：第三題規格書（動作要求、參數設定、計算範例、HMI/PLC 暫存器規劃、機具設備表、動作程序表）
- 單位約定（HMI 小數一位，PLC 內部皆為整數）
  - 位置：0.1 mm 為 1（50.0 mm = 500）；停留時間、連續進給時間 TC：0.1 s 為 1（3.0 s = 30）
  - 速度：rpm 整數；輸出頻率：內部以 Hz 計算，顯示用 0.1 kHz 為 1
  - 脈波換算（規格書計算範例）：2048 pulse/rev、10 mm/rev
    - 脈波數 = 2048 × (距離 mm / 10)　→　1 mm = 204.8 pulse
    - 頻率 Hz = rpm × 2048 / 60

## 使用說明

1. 依「標籤與軟元件對照表」建立全域標籤。
2. 建立兩個使用者函數 `Pls2X10`、`Rpm2Hz`（FUN 1、FUN 2 區段）。
3. 建立主程式（「主程式」區段），每掃描執行。
4. 模組參數設定（GX Works3 → 模組參數 → 高速 I/O）：
   - 定位 軸1：脈波輸出模式「脈波＋方向」，脈波 Y0、方向 Y4，最高速度 ≥ 20480 Hz（600 rpm），加減速時間 100 ms 左右，偏置速度 0。
   - 高速計數器 CH1：A 相 X0、B 相 X1，相位模式「A/B 相 1 倍」（手搖輪 100 PPR → 每轉 100 計數＝100 刻度）。
5. 以下假設請依實機確認，不同時只需改標籤對照表：
   - 極限感測器、原點感測器：被遮蔽（動作）時為 ON；原點感測器為一段「遮光區」，向左移動時先遇「上緣」（OFF→ON），再遇「下緣」（ON→OFF）。
   - EMS 為 1b 接點（平時 ON，按下 OFF）；COS 為 1a1b 三段式，兩個接點各對應位置 1、位置 2，皆 OFF 為位置 0。
   - 伺服驅動器：準備完成 X12＝ON 表示就緒；警報 X13＝ON 表示異常；正/反轉禁止輸入由 PLC 輸出 Y10/Y11 送出（ON＝允許）。
   - HMI 警報彈出視窗（任意頁面）使用 M200～M202。
   - 手搖輪「一刻度」定義為顯示解析度 0.1 mm（×1 時轉一格走 0.1 mm，×10 走 1 mm，×100 走 10 mm）。
   - 手搖輪速度（低/中/高）為常數 `MPG_HZ_L / M / H`，可自行調整。
6. 本程式未於實機/模擬器編譯測試。脈波指令（`DDRVA_E`、`DDRVI_E`、`DPLSV_E`）、軸 BUSY（SM5500）、軸現在位址（SD5300）、HSC CH1 現在值（SD4500）請對照所用 GX Works3 版本與 FX5U 手冊確認指令名稱與軟元件編號，這些只集中在「軸命令定序器／軸輸出」與標籤表中。

## 完整程式碼

```pascal
(*==========================================================================
  第三題：多段行程教導運轉定位與顯示控制
  三菱 MELSEC iQ-F (FX5U) / GX Works3  ST 語言
  --------------------------------------------------------------------------
  一、標籤(Label)與軟元件對照表
  --------------------------------------------------------------------------
  【輸入】
   MPG_A       BOOL  X0    手搖輪 A 相 (HSC CH1)
   MPG_B       BOOL  X1    手搖輪 B 相 (HSC CH1)
   COS1_P1     BOOL  X2    COS1 模式：位置 1 (連續運轉) 接點
   COS1_P2     BOOL  X3    COS1 模式：位置 2 (定點設定) 接點；兩者皆 OFF = 位置 0 (單步運轉)
   COS2_P1     BOOL  X4    COS2 MPG 倍率：位置 1 (x1)
   COS2_P2     BOOL  X5    COS2 MPG 倍率：位置 2 (x100)；兩者皆 OFF = 位置 0 (x10)
   EMS_NC      BOOL  X6    緊急停止 EMS (1b：平時 ON，按下 OFF)
   LS_L_In     BOOL  X7    左極限感測器 (動作 ON)
   LS_R_In     BOOL  X10   右極限感測器 (動作 ON)
   ORG_In      BOOL  X11   機械原點感測器 (遮光區 ON)
   SRDY        BOOL  X12   伺服驅動器 準備完成 (ON=就緒)
   SALM        BOOL  X13   伺服驅動器 警報輸出 (ON=異常)
  【輸出】
   (Y0)        脈波輸出 (PULSE)   (Y4) 方向輸出 (DIR)  ← 由定位指令使用
   MC1_Y       BOOL  Y5    MC1 電磁接觸器
   SON_Y       BOOL  Y6    伺服 ON
   ALMRST_Y    BOOL  Y7    伺服警報復歸
   LSP_Y       BOOL  Y10   正轉(右)禁止輸入 (ON=允許)
   LSN_Y       BOOL  Y11   反轉(左)禁止輸入 (ON=允許)
  【HMI 位元 (規格書暫存器規劃)】
   M100 移動量切換鍵    M101 START   M102 STOP   M103 原點(HOME)   M104 儲存(SAVE)
   M111 JOG+            M112 JOG-
   M190~M193  A~D 位置閃爍 (1=亮 / 0=熄)；不閃爍時恆為 1
   M200 行程超出左極限警報   M201 行程超出右極限警報   M202 緊急停機警報  (任意頁面彈出)
  【HMI 暫存器 (規格書暫存器規劃)】
   R100 寸動進給速度(rpm)    DR104 寸動進給輸出頻率(0.1kHz)
   R102 連續進給速度(rpm)    DR106 連續進給輸出頻率(0.1kHz)
   R108 連續進給時間 TC (0.1s)   R109 模式顯示 (0=單步運轉 1=連續運轉 2=定點設定)
   R110 寸動進給移動量 (5/10/20 mm)
   R120 滑台A(mm,0.1)  R121 滑台B  R122 滑台C  R123 滑台D   R124 目前位置
   R135 停留時間 T0   R136 T1   R137 T2   R138 T3   (0.1s)
   R141 速度 SP1  R142 SP2  R143 SP3  (rpm)
  【特殊軟元件】
   Ax_Busy     BOOL  SM5500  軸1 脈波輸出中 (BUSY)        ※請對照手冊確認
   Axis_Cur    DINT  SD5300  軸1 現在位址 (脈波數)，停止時可寫入 0 作為原點
   HSC1_Val    DINT  SD4500  HSC CH1 現在值 (手搖輪計數)
   First_Scan  BOOL  SM402   RUN 後第一個掃描 ON
  【常數 Constant】
   PLS_REV 2048   MM_REV 10   HOME_FAST_RPM 150   HOME_SLOW_RPM 10
   MPG_HZ_L 1000  MPG_HZ_M 4000  MPG_HZ_H 12000   MPG_ACC_MAX 1000 (刻度，限制單次累積行程)
   MODE_STEP 0  MODE_CONT 1  MODE_SET 2
   ST_IDLE 0   ST_JOG_INC 10  ST_JOG_WAIT 11  ST_JOG_CONT 12   ST_MPG 20
   ST_HOME_FAST 30  ST_HOME_SLOW 31  ST_HOME_STOP 32
   ST_STEP_MOVE 40  ST_CONT_MOVE 50  ST_CONT_DWELL 51  ST_CONT_T0 52
  【保持型(Retain)標籤】 無 (斷電後須重新回原點，符合「未於原點須先回原點」要求)
  【區域標籤】
   St, Mode_Sel, Mode_Eff, Mult, Home_Ctx, Step_Idx, Cont_Idx, Go_Req, Go_Ctx,
   Go_Idx, Set_Idx, Jog_Dir, Dir_Cmd, Fl_Sel, Fl_Cnt, Ax_St, Ax_Kind   : INT
   Jog_Hz, Cont_Hz, Mpg_Hz, Ax_Tgt, Ax_Hz, Ax_VelHz, Cur_Pls, Mpg_Prev, Mpg_Dlt,
   Mpg_Acc, Mpg_Base, Mpg_Tgt, Mpg_Last, Dwell_x10                      : DINT
   Pt                                                                   : ARRAY[1..3] OF DINT
   EMS_OK, LS_L, LS_R, Org_On, MC1_On, Op_Enable, Ems_Latch, Homed, Pt_Ok,
   Is_Origin, Stop_Req, Cont_Run, Jog_Held, Abort_Lim, Ax_Free, Ax_Done,
   Ax_Abort, Ax_ReqAbs, Ax_ReqRel, Ax_AbsOn, Ax_RelOn, Ax_VelOn,
   Fl_Run, Fl_3, Blk_En, Blk                                            : BOOL
   T_Pwr, T_Son, T_TC, T_Dwell, T_AxWt, T_B1, T_B2                      : TON
   R_Start, R_Stop, R_Home, R_Save, R_Mv, R_JogP, R_JogM, R_OrgUp, R_Blk  : R_TRIG
   F_OrgDn                                                              : F_TRIG
==========================================================================*)


(*==========================================================================
  FUN 1：Pls2X10   (脈波數 → 0.1mm)  回傳 INT   四捨五入
  VAR_INPUT  P : DINT;      1mm = 2048/10 pulse
==========================================================================*)
IF P >= 0 THEN
    Pls2X10 := DINT_TO_INT( (P * 100 + 1024) / 2048 );
ELSE
    Pls2X10 := DINT_TO_INT( (P * 100 - 1024) / 2048 );
END_IF;


(*==========================================================================
  FUN 2：Rpm2Hz   (rpm → 輸出頻率 Hz)  回傳 DINT
  VAR_INPUT  N : INT;       Hz = rpm × 2048 / 60
==========================================================================*)
Rpm2Hz := MAX( INT_TO_DINT(N) * 2048 / 60, 10 );


(*==========================================================================
  主程式 (Program，每掃描執行)
==========================================================================*)

(*---------------- 1. 輸入處理 ----------------*)
EMS_OK := EMS_NC;
LS_L   := LS_L_In;
LS_R   := LS_R_In;
Org_On := ORG_In;

R_Start(CLK := M101);   R_Stop(CLK := M102);   R_Home(CLK := M103);
R_Save (CLK := M104);   R_Mv  (CLK := M100);
R_JogP (CLK := M111);   R_JogM(CLK := M112);
R_OrgUp(CLK := Org_On); F_OrgDn(CLK := Org_On);

// COS1 模式：位置1=連續運轉 位置2=定點設定 位置0=單步運轉
IF COS1_P1 AND (NOT COS1_P2) THEN
    Mode_Sel := MODE_CONT;
ELSIF COS1_P2 AND (NOT COS1_P1) THEN
    Mode_Sel := MODE_SET;
ELSIF (NOT COS1_P1) AND (NOT COS1_P2) THEN
    Mode_Sel := MODE_STEP;
END_IF;

// COS2 手搖輪倍率：位置1=x1 位置2=x100 位置0=x10
IF COS2_P1 AND (NOT COS2_P2) THEN
    Mult := 1;
ELSIF COS2_P2 AND (NOT COS2_P1) THEN
    Mult := 100;
ELSIF (NOT COS2_P1) AND (NOT COS2_P2) THEN
    Mult := 10;
END_IF;

CASE Mult OF
    1:   Mpg_Hz := MPG_HZ_L;     // 低速
    10:  Mpg_Hz := MPG_HZ_M;     // 中速
ELSE
    Mpg_Hz := MPG_HZ_H;          // 高速
END_CASE;

(*---------------- 2. 送電初始化 ----------------*)
IF First_Scan THEN
    St := ST_IDLE;  Mode_Eff := Mode_Sel;
    Homed := FALSE; Pt_Ok := FALSE;
    Step_Idx := 0;  Cont_Idx := 0;  Set_Idx := 0;
    Cont_Run := FALSE; Stop_Req := FALSE;
    Mpg_Prev := HSC1_Val;  Mpg_Acc := 0;
    IF (R110 <> 5) AND (R110 <> 10) AND (R110 <> 20) THEN
        R110 := 5;                                           // 寸動移動量預設 x5mm
    END_IF;
END_IF;

(*---------------- 3. 受電／MC1／伺服 (含 EMS) ----------------*)
// NFB ON、PLC 受電 5 秒後 MC1 動作；EMS 解除栓鎖後亦經 5 秒 MC1 才動作
T_Pwr(IN := EMS_OK, PT := T#5s);
MC1_On := T_Pwr.Q;
T_Son(IN := MC1_On, PT := T#1s);                             // MC1 動作 1 秒後伺服 ON
Op_Enable := MC1_On AND T_Son.Q AND SRDY AND (NOT SALM) AND EMS_OK;

MC1_Y    := MC1_On;
SON_Y    := T_Son.Q;
ALMRST_Y := MC1_On AND (NOT T_Son.Q);                        // 送電時復歸一次伺服警報
LSP_Y    := NOT LS_R;                                        // 右極限 → 禁止正轉
LSN_Y    := NOT LS_L;                                        // 左極限 → 禁止反轉

// 緊急停機警報：EMS 按下起，至 MC1 恢復動作止
IF NOT EMS_OK THEN
    Ems_Latch := TRUE;
ELSIF MC1_On THEN
    Ems_Latch := FALSE;
END_IF;

(*---------------- 4. 參數與顯示計算 (HMI) ----------------*)
Jog_Hz  := Rpm2Hz(R100);                                     // 寸動進給頻率
Cont_Hz := Rpm2Hz(R102);                                     // 連續進給頻率
DR104   := (Jog_Hz  + 50) / 100;                             // 顯示 kHz，一位小數
DR106   := (Cont_Hz + 50) / 100;

// 移動量切換鍵：x5mm → x10mm → x20mm → x5mm …
IF R_Mv.Q THEN
    IF R110 = 5 THEN
        R110 := 10;
    ELSIF R110 = 10 THEN
        R110 := 20;
    ELSE
        R110 := 5;
    END_IF;
END_IF;

Cur_Pls := Axis_Cur;
R124 := Pls2X10(Cur_Pls);                                    // 目前位置
R120 := 0;                                                   // 滑台 A = 機械原點 = 0
R121 := Pls2X10(Pt[1]);                                      // 滑台 B (第一定位點)
R122 := Pls2X10(Pt[2]);                                      // 滑台 C
R123 := Pls2X10(Pt[3]);                                      // 滑台 D
R109 := Mode_Eff;                                            // 模式顯示

Is_Origin := Homed AND (Cur_Pls = 0);

(*---------------- 5. 警報 (顯示於任意 HMI 頁面) ----------------*)
M200 := LS_L;                                                // 行程超出左極限
M201 := LS_R;                                                // 行程超出右極限
M202 := Ems_Latch;                                           // 緊急停機

(*---------------- 6. 手搖輪 (MPG) 計數累積 ----------------*)
Mpg_Dlt  := HSC1_Val - Mpg_Prev;
Mpg_Prev := HSC1_Val;
IF (Mode_Eff = MODE_SET) AND Op_Enable AND ((St = ST_IDLE) OR (St = ST_MPG)) THEN
    // 往極限方向的計數不累積
    IF ((Mpg_Dlt > 0) AND (NOT LS_R)) OR ((Mpg_Dlt < 0) AND (NOT LS_L)) THEN
        Mpg_Acc := Mpg_Acc + Mpg_Dlt * INT_TO_DINT(Mult);    // 單位：0.1mm 刻度
        IF Mpg_Acc >  MPG_ACC_MAX THEN Mpg_Acc :=  MPG_ACC_MAX; END_IF;
        IF Mpg_Acc < -MPG_ACC_MAX THEN Mpg_Acc := -MPG_ACC_MAX; END_IF;
    END_IF;
ELSIF St <> ST_MPG THEN
    Mpg_Acc := 0;
END_IF;

(*---------------- 7. 計時器 (依目前狀態驅動) ----------------*)
// 寸動按壓時間是否超過連續進給時間 TC
Jog_Held := ((Jog_Dir > 0) AND M111) OR ((Jog_Dir < 0) AND M112);
T_TC(IN := ((St = ST_JOG_INC) OR (St = ST_JOG_WAIT)) AND Jog_Held,
     PT := DINT_TO_TIME( INT_TO_DINT(R108) * 100 ));

// 定位點停留時間 T0~T3
CASE St OF
    ST_CONT_T0:    Dwell_x10 := INT_TO_DINT(R135);
    ST_CONT_DWELL:
        CASE Cont_Idx OF
            1:  Dwell_x10 := INT_TO_DINT(R136);
            2:  Dwell_x10 := INT_TO_DINT(R137);
        ELSE
            Dwell_x10 := INT_TO_DINT(R138);
        END_CASE;
ELSE
    Dwell_x10 := 0;
END_CASE;
T_Dwell(IN := (St = ST_CONT_DWELL) OR (St = ST_CONT_T0),
        PT := DINT_TO_TIME( Dwell_x10 * 100 ));

T_AxWt(IN := (Ax_St = 1), PT := T#200ms);

(*---------------- 8. 主控制流程 ----------------*)
Ax_Free   := (Ax_St = 0) AND (NOT Ax_Busy) AND (NOT Ax_VelOn);   // 軸可接受新命令
Ax_VelOn  := FALSE;                                              // 速度命令每掃描由狀態重新給定
Ax_ReqAbs := FALSE;
Ax_ReqRel := FALSE;
Ax_Abort  := FALSE;
Go_Req    := 0;

// 往極限方向運動時碰觸極限 → 馬達停止
Abort_Lim := ((Dir_Cmd > 0) AND LS_R) OR ((Dir_Cmd < 0) AND LS_L);

IF (NOT Op_Enable) OR ((St <> ST_IDLE) AND Abort_Lim) THEN
    // EMS、伺服異常、MC1 尚未動作或碰觸極限：全部中止，回到待機
    IF NOT EMS_OK THEN
        Homed := FALSE;                                      // EMS 後須重新回原點
    END_IF;
    Ax_Abort := TRUE;
    St := ST_IDLE;   Dir_Cmd := 0;
    Step_Idx := 0;   Cont_Idx := 0;   Cont_Run := FALSE;   Stop_Req := FALSE;
    Mpg_Acc := 0;
ELSE
    CASE St OF

    ST_IDLE:
        Dir_Cmd   := 0;
        Mode_Eff  := Mode_Sel;                               // 模式切換僅在停止後生效
        IF Mpg_Acc = 0 THEN
            Mpg_Base := Cur_Pls;                             // 手搖輪行程基準點
        END_IF;

        IF Ax_Free THEN
            IF (R_JogP.Q AND (NOT M112) AND (NOT LS_R))
               OR (R_JogM.Q AND (NOT M111) AND (NOT LS_L)) THEN
                // ---- 寸動：點位進給，按壓超過 TC 轉連續進給 ----
                IF R_JogP.Q THEN
                    Jog_Dir := 1;
                ELSE
                    Jog_Dir := -1;
                END_IF;
                Ax_Tgt    := INT_TO_DINT(R110) * 2048 / 10 * INT_TO_DINT(Jog_Dir);  // 相對脈波
                Ax_Hz     := Jog_Hz;
                Ax_ReqRel := TRUE;
                Dir_Cmd   := Jog_Dir;
                St        := ST_JOG_INC;

            ELSIF R_Home.Q AND (NOT LS_L) THEN
                // ---- 回原點 ----
                Home_Ctx := 0;
                Fl_Sel   := 1;                               // A 位置閃爍
                Dir_Cmd  := -1;
                IF Org_On THEN
                    St := ST_HOME_SLOW;
                ELSE
                    St := ST_HOME_FAST;
                END_IF;

            ELSIF R_Save.Q AND (Mode_Eff = MODE_SET) AND Homed AND (Set_Idx < 3) THEN
                // ---- 儲存定位點 B / C / D ----
                Set_Idx     := Set_Idx + 1;
                Pt[Set_Idx] := Cur_Pls;
                IF Set_Idx = 3 THEN
                    Pt_Ok := TRUE;
                END_IF;
                Fl_Sel := Set_Idx + 1;                       // B=2 C=3 D=4
                Fl_Cnt := 0;
                Fl_3   := TRUE;                              // 以設定值閃爍三次

            ELSIF R_Start.Q AND Pt_Ok AND (Mode_Eff = MODE_STEP) THEN
                // ---- 單步運轉：每按一次 START 走一步 ----
                Go_Ctx := 1;
                CASE Step_Idx OF
                    0:  IF Is_Origin THEN Go_Req := 1; END_IF;
                    1:  IF Cur_Pls = Pt[1] THEN Go_Req := 2; END_IF;
                    2:  IF Cur_Pls = Pt[2] THEN Go_Req := 3; END_IF;
                    3:  IF Cur_Pls = Pt[3] THEN
                            Home_Ctx := 1;                   // 回機械原點
                            Fl_Sel   := 1;
                            Dir_Cmd  := -1;
                            IF Org_On THEN St := ST_HOME_SLOW; ELSE St := ST_HOME_FAST; END_IF;
                        END_IF;
                END_CASE;

            ELSIF R_Start.Q AND Pt_Ok AND (Mode_Eff = MODE_CONT) AND Is_Origin THEN
                // ---- 連續運轉：自原點起算 ----
                Cont_Run := TRUE;
                Stop_Req := FALSE;
                Cont_Idx := 1;
                Go_Ctx   := 2;
                Go_Req   := 1;

            ELSIF (Mode_Eff = MODE_SET) AND (Mpg_Acc <> 0) THEN
                // ---- 手搖輪：依倍率與累積刻度移動 ----
                Mpg_Tgt   := Mpg_Base + Mpg_Acc * 2048 / 100;
                Mpg_Last  := Mpg_Tgt;
                Ax_Tgt    := Mpg_Tgt;
                Ax_Hz     := Mpg_Hz;
                Ax_ReqAbs := TRUE;
                IF Mpg_Acc > 0 THEN Dir_Cmd := 1; ELSE Dir_Cmd := -1; END_IF;
                St := ST_MPG;
            END_IF;
        END_IF;

    ST_JOG_INC:                                              // 點位進給執行中
        IF Ax_Done THEN
            IF Jog_Held AND T_TC.Q THEN
                St := ST_JOG_CONT;
            ELSIF Jog_Held THEN
                St := ST_JOG_WAIT;
            ELSE
                St := ST_IDLE;  Dir_Cmd := 0;
            END_IF;
        END_IF;

    ST_JOG_WAIT:                                             // 等待放開或達 TC
        IF NOT Jog_Held THEN
            St := ST_IDLE;  Dir_Cmd := 0;
        ELSIF T_TC.Q THEN
            St := ST_JOG_CONT;
        END_IF;

    ST_JOG_CONT:                                             // 連續進給速度移動
        IF Jog_Held THEN
            Ax_VelOn := TRUE;
            Ax_VelHz := Cont_Hz * INT_TO_DINT(Jog_Dir);
        ELSE
            St := ST_IDLE;  Dir_Cmd := 0;
        END_IF;

    ST_MPG:                                                  // 手搖輪移動中
        IF Ax_Done THEN
            Mpg_Tgt := Mpg_Base + Mpg_Acc * 2048 / 100;
            IF (Mpg_Tgt <> Mpg_Last) AND (Mpg_Acc <> 0) THEN
                Mpg_Last  := Mpg_Tgt;                        // 移動中又有新刻度：追加移動
                Ax_Tgt    := Mpg_Tgt;
                Ax_Hz     := Mpg_Hz;
                Ax_ReqAbs := TRUE;
                IF Mpg_Tgt > Cur_Pls THEN Dir_Cmd := 1; ELSE Dir_Cmd := -1; END_IF;
            ELSE
                Mpg_Acc := 0;
                St := ST_IDLE;  Dir_Cmd := 0;
            END_IF;
        END_IF;

    ST_HOME_FAST:                                            // 以 150rpm 向原點(左)移動
        Ax_VelOn := TRUE;
        Ax_VelHz := -Rpm2Hz(HOME_FAST_RPM);
        IF R_OrgUp.Q THEN                                    // 碰觸原點上緣 → 改 10rpm
            St := ST_HOME_SLOW;
        END_IF;

    ST_HOME_SLOW:                                            // 以 10rpm 移動
        Ax_VelOn := TRUE;
        Ax_VelHz := -Rpm2Hz(HOME_SLOW_RPM);
        IF F_OrgDn.Q THEN                                    // 碰觸原點下緣 → 停止
            St := ST_HOME_STOP;
        END_IF;

    ST_HOME_STOP:                                            // 停止後現在位置歸零
        IF Ax_Free THEN
            Axis_Cur := 0;
            Homed    := TRUE;
            Set_Idx  := 0;
            Step_Idx := 0;
            Dir_Cmd  := 0;
            CASE Home_Ctx OF
                2:  // 連續運轉回到原點：STOP 或模式已切換 → 停止；否則停留 T0 後再循環
                    IF Stop_Req OR (Mode_Sel <> Mode_Eff) THEN
                        Cont_Run := FALSE;  Stop_Req := FALSE;  Cont_Idx := 0;
                        St := ST_IDLE;
                    ELSE
                        St := ST_CONT_T0;
                    END_IF;
            ELSE
                St := ST_IDLE;
            END_CASE;
        END_IF;

    ST_STEP_MOVE:                                            // 單步：移動到指定定位點
        IF Ax_Done THEN
            Step_Idx := Go_Idx;
            Dir_Cmd  := 0;
            St := ST_IDLE;
        END_IF;

    ST_CONT_MOVE:                                            // 連續：移動到指定定位點
        IF Ax_Done THEN
            Dir_Cmd := 0;
            St := ST_CONT_DWELL;
        END_IF;

    ST_CONT_DWELL:                                           // 停留 T1 / T2 / T3
        IF T_Dwell.Q THEN
            IF Cont_Idx < 3 THEN
                Cont_Idx := Cont_Idx + 1;
                Go_Ctx   := 2;
                Go_Req   := Cont_Idx;
            ELSE                                             // T3 後以回原點速度回原點
                Home_Ctx := 2;
                Fl_Sel   := 1;
                Dir_Cmd  := -1;
                IF Org_On THEN St := ST_HOME_SLOW; ELSE St := ST_HOME_FAST; END_IF;
            END_IF;
        END_IF;

    ST_CONT_T0:                                              // 原點停留 T0 後再以 SP1 走向 B
        IF T_Dwell.Q THEN
            Cont_Idx := 1;
            Go_Ctx   := 2;
            Go_Req   := 1;
        END_IF;

    ELSE
        St := ST_IDLE;
    END_CASE;

    // 連續運轉中按 STOP：繼續動作到回原點才停止
    IF R_Stop.Q AND Cont_Run THEN
        Stop_Req := TRUE;
    END_IF;

    // 定位點移動命令 (單步 / 連續共用)：Go_Req = 1,2,3 → B,C,D，速度 SP1,SP2,SP3
    IF Go_Req > 0 THEN
        CASE Go_Req OF
            1:  Ax_Tgt := Pt[1];  Ax_Hz := Rpm2Hz(R141);
            2:  Ax_Tgt := Pt[2];  Ax_Hz := Rpm2Hz(R142);
        ELSE
            Ax_Tgt := Pt[3];  Ax_Hz := Rpm2Hz(R143);
        END_CASE;
        Ax_ReqAbs := TRUE;
        IF Ax_Tgt > Cur_Pls THEN
            Dir_Cmd := 1;
        ELSIF Ax_Tgt < Cur_Pls THEN
            Dir_Cmd := -1;
        ELSE
            Dir_Cmd := 0;
        END_IF;
        Fl_Sel := Go_Req + 1;                                // B=2 C=3 D=4 閃爍
        Go_Idx := Go_Req;
        IF Go_Ctx = 1 THEN
            St := ST_STEP_MOVE;
        ELSE
            St := ST_CONT_MOVE;
        END_IF;
    END_IF;
END_IF;

(*---------------- 9. 軸命令定序器 (絕對/相對定位完成判斷) ----------------*)
Ax_Done := FALSE;
CASE Ax_St OF
    0:  IF Ax_Abort THEN
            ;
        ELSIF Ax_ReqAbs THEN
            Ax_Kind := 1;  Ax_St := 1;
        ELSIF Ax_ReqRel THEN
            Ax_Kind := 2;  Ax_St := 1;
        END_IF;
    1:  // 指令導通，等待軸 BUSY (目標=現在位置時指令立即完成，以 200ms 逾時判定)
        IF Ax_Abort THEN
            Ax_St := 0;
        ELSIF Ax_Busy THEN
            Ax_St := 2;
        ELSIF T_AxWt.Q THEN
            Ax_Done := TRUE;  Ax_St := 0;
        END_IF;
    2:  IF Ax_Abort THEN
            Ax_St := 0;
        ELSIF NOT Ax_Busy THEN
            Ax_Done := TRUE;  Ax_St := 0;
        END_IF;
END_CASE;

Ax_AbsOn := (Ax_St <> 0) AND (Ax_Kind = 1) AND Op_Enable;
Ax_RelOn := (Ax_St <> 0) AND (Ax_Kind = 2) AND Op_Enable;
Ax_VelOn := Ax_VelOn AND Op_Enable;

(*---------------- 10. 軸輸出 (FX5U 內建脈波輸出：Y0 脈波 / Y4 方向) ----------------*)
// ※ 指令名稱依 GX Works3 版本確認；指令導通＝執行，斷開＝減速停止
DDRVA_E(Ax_AbsOn, Ax_Tgt,   Ax_Hz,    Y0, Y4);               // 絕對位置定位 (位置點移動、手搖輪)
DDRVI_E(Ax_RelOn, Ax_Tgt,   Ax_Hz,    Y0, Y4);               // 相對位置定位 (寸動點位進給)
DPLSV_E(Ax_VelOn, Ax_VelHz,           Y0, Y4);               // 可變速脈波 (連續寸動、回原點；負值＝向左)

(*---------------- 11. 位置閃爍 (A~D 數值顯示) ----------------*)
// 移動中：目標位置數值閃爍 (亮0.5s/熄0.5s)；儲存定位點：以設定值閃爍三次
Fl_Run := (St = ST_HOME_FAST) OR (St = ST_HOME_SLOW) OR (St = ST_HOME_STOP)
          OR (St = ST_STEP_MOVE) OR (St = ST_CONT_MOVE);
Blk_En := Fl_Run OR Fl_3;

T_B1(IN := Blk_En AND (NOT T_B2.Q), PT := T#500ms);
T_B2(IN := T_B1.Q,                  PT := T#500ms);
Blk := Blk_En AND (NOT T_B1.Q);

R_Blk(CLK := Blk);
IF Fl_3 AND R_Blk.Q THEN
    Fl_Cnt := Fl_Cnt + 1;
    IF Fl_Cnt >= 4 THEN                                      // 起始亮 + 三次(熄→亮) 完成
        Fl_3 := FALSE;
    END_IF;
END_IF;

// M190~M193：1=亮 0=熄；非閃爍中的位置恆亮
M190 := (NOT (Blk_En AND (Fl_Sel = 1))) OR Blk;              // A
M191 := (NOT (Blk_En AND (Fl_Sel = 2))) OR Blk;              // B
M192 := (NOT (Blk_En AND (Fl_Sel = 3))) OR Blk;              // C
M193 := (NOT (Blk_En AND (Fl_Sel = 4))) OR Blk;              // D
```
