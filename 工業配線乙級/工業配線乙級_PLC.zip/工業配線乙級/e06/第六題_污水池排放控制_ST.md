# 第六題 污水池排放控制 — 三菱 MELSEC ST 程式

> 語言：IEC 61131-3 Structured Text（GX Works3 / iQ-F、iQ-R 皆可；FX 系列 X、Y 位址為八進位）
> 1Hz 閃爍使用 `SM412`（1 秒時脈，ON 0.5s / OFF 0.5s）。若使用 FX3U，請改用 `M8013`。

---

## 1. I/O 分配表

### 輸入

| 標籤 | 位址 | 元件 | 說明 |
| --- | --- | --- | --- |
| PB1 | X0 | PB1 NO | 自動／手動開始運轉 |
| PB2 | X1 | PB2 NO | 手動：SV 開啟／關閉 |
| PB3 | X2 | PB3 NO | 手動：M1 運轉／停止 |
| PB4 | X3 | PB4 NO | 手動：M2 低速／停止 |
| PB5 | X4 | PB5 NO | 故障復歸、BZ 消音 |
| EMS_NC | X5 | PB6 NC | 緊急停止（正常 ON，按下或斷線 OFF） |
| COS_1 | X6 | COS-1 | 手動 |
| COS_2 | X7 | COS-2 | 自動 |
| PXS1 | X10 | 近接開關 S1 | 水位到達 S1 時 ON |
| PXS2 | X11 | 近接開關 S2 | 同上 |
| PXS3 | X12 | 近接開關 S3 | 同上 |
| PXS4 | X13 | 近接開關 S4 | 同上 |
| PXS5 | X14 | 近接開關 S5 | 同上 |
| PXS6 | X15 | 近接開關 S6 | 同上 |
| OL_SMC | X16 | 緩啟動器 Tc-Tb | 正常 ON，過載或斷線 OFF |
| OL_INV | X17 | 變頻器 Tc-Tb | 正常 ON，過載或斷線 OFF |

> COS 切於 0 時 X6、X7 皆 OFF。

### 輸出

| 標籤 | 位址 | 元件 | 說明 |
| --- | --- | --- | --- |
| PL1 | Y0 | PL1 | M1 運轉燈 |
| PL2 | Y1 | PL2 | M2 運轉燈 |
| PL3 | Y2 | PL3（代替 SV） | 污水入口電磁閥 SV |
| PL4 | Y3 | PL4 | 訊息碼 4 |
| PL5 | Y4 | PL5 | 訊息碼 2 |
| PL6 | Y5 | PL6 | 訊息碼 1 |
| BZ | Y6 | BZ | 蜂鳴器 |
| MC1 | Y7 | MC1 | 緩啟動器電源 |
| MC2 | Y10 | MC2 | 變頻器電源 |
| SMC_START | Y11 | 緩啟動器啟動接點 | ON 啟動 M1 |
| INV_FWD | Y12 | 變頻器 FWD | ON 正轉運轉 |
| INV_SPS | Y13 | 變頻器 SPS | ON 低速 40%；OFF 高速 100%（見假設 4） |
| SV | Y14 | 污水入口電磁閥 | 規格 六：I/O 圖須標示 SV 輸出位置，不必實際配線；檢定時以 PL3 代替 |

---

## 2. 標籤宣告

| 標籤 | 型態 | 用途 |
| --- | --- | --- |
| RUN | BOOL | PB1 運轉自保（MC1、MC2 ON） |
| NORMAL | BOOL | 運轉中且無異常 |
| FAULT | BOOL | 異常鎖定（EMS 或過載） |
| OLF | BOOL | 過載異常記憶 |
| OL_NOW | BOOL | 目前過載中 |
| M1_AUTO / M2_AUTO | BOOL | 自動：M1、M2 水位記憶 |
| SV_OFF | BOOL | 自動：SV 關閉記憶 |
| BZ_SIL | BOOL | 自動：BZ 已按 PB5 消音 |
| SV_MAN / M1_MAN / M2_MAN | BOOL | 手動：各按鈕切換狀態 |
| M1_CMD / M2_CMD / M2_HI / SV_CMD | BOOL | 運轉命令 |
| PB1_OLD … PB5_OLD、P_PB1 … P_PB5 | BOOL | 按鈕上升緣 |
| MODE_ON / AUTO / MANU / EMS_ACT / F_CLR | BOOL | 中間變數 |
| CODE_EN | BOOL | 水位訊息碼顯示許可（COS 在 1／2 且無異常，不需 RUN） |
| LV | INT | 水位代碼 0～6 |
| T_M1 | TON | M1 緩啟動 3 秒（PL1 閃爍轉恆亮） |
| T_OLEN | TON | MC 吸入後 1 秒才監控過載 |

---

## 3. ST 程式

```pascal
(*==================================================================*)
(* 第六題 污水池排放控制                                              *)
(*==================================================================*)

(*---------- 0. 按鈕上升緣 ----------*)
P_PB1 := PB1 AND (NOT PB1_OLD);
P_PB2 := PB2 AND (NOT PB2_OLD);
P_PB3 := PB3 AND (NOT PB3_OLD);
P_PB4 := PB4 AND (NOT PB4_OLD);
P_PB5 := PB5 AND (NOT PB5_OLD);

(*---------- 1. 模式、緊急停止、過載判斷 ----------*)
MODE_ON := COS_1 OR COS_2;          (* COS 不在 0 *)
AUTO    := COS_2;
MANU    := COS_1;
EMS_ACT := NOT EMS_NC;              (* 按下或接點線路斷線 *)

(* MC 吸入 1 秒後才監控過載接點，避免啟動瞬間誤判 *)
T_OLEN(IN := RUN, PT := T#1s);
OL_NOW := T_OLEN.Q AND ((NOT OL_SMC) OR (NOT OL_INV));   (* 斷線等同跳脫 *)

(*---------- 2. 異常鎖定與復歸 ----------*)
F_CLR := FALSE;
IF NOT MODE_ON THEN                 (* COS 切 0：全部解除 *)
    FAULT := FALSE;
    OLF   := FALSE;
ELSE
    IF EMS_ACT OR OL_NOW THEN
        FAULT := TRUE;
    END_IF;
    IF OL_NOW THEN
        OLF := TRUE;
    END_IF;
    (* EMS 已解除、過載接點已復歸後按 PB5 才可復歸 *)
    IF FAULT AND P_PB5 AND (NOT EMS_ACT) AND (NOT OL_NOW) THEN
        FAULT := FALSE;
        OLF   := FALSE;
        F_CLR := TRUE;
    END_IF;
END_IF;

(*---------- 3. 運轉自保（PB1）----------*)
(* 異常復歸後回到初始狀態，需再按 PB1 才依水位重新運轉 *)
IF (NOT MODE_ON) OR F_CLR THEN
    RUN := FALSE;
ELSIF P_PB1 AND (NOT FAULT) AND (NOT EMS_ACT) THEN
    RUN := TRUE;
END_IF;

NORMAL := RUN AND (NOT FAULT);

(* 水位訊息碼：COS 在 1／2 且無異常即顯示，不需先按 PB1。
   規格 貳(2)19、肆7、伍7、柒5：異常復歸後 RUN 已解除，訊息碼仍須顯示 *)
CODE_EN := MODE_ON AND (NOT FAULT);

(*---------- 4. 自動：水位記憶（上升／下降遲滯）----------*)
IF AUTO THEN
    M1_AUTO := (PXS2 OR M1_AUTO) AND PXS1;   (* S2 ON 啟動；低於 S1 停止 *)
    M2_AUTO := (PXS3 OR M2_AUTO) AND PXS2;   (* S3 ON 加入；低於 S2 停止 *)
    SV_OFF  := (PXS6 OR SV_OFF)  AND PXS5;   (* S6 ON 關閉；低於 S5 重新開啟 *)
ELSE
    M1_AUTO := FALSE;
    M2_AUTO := FALSE;
    SV_OFF  := FALSE;
END_IF;

(* BZ 消音：S5 以上按 PB5 消音，低於 S5 解除消音記憶 *)
IF NORMAL AND AUTO AND P_PB5 AND PXS5 THEN
    BZ_SIL := TRUE;
END_IF;
IF (NOT PXS5) OR (NOT NORMAL) OR (NOT AUTO) THEN
    BZ_SIL := FALSE;
END_IF;

(*---------- 5. 手動：按鈕切換與水位互鎖 ----------*)
IF NORMAL AND MANU THEN
    IF P_PB2 AND (NOT PXS5) THEN SV_MAN := NOT SV_MAN; END_IF;   (* 低於 S5 才可開 SV *)
    IF P_PB3 AND PXS2       THEN M1_MAN := NOT M1_MAN; END_IF;   (* 高於 S2 才可運轉 M1 *)
    IF P_PB4 AND PXS3       THEN M2_MAN := NOT M2_MAN; END_IF;   (* 高於 S3 才可運轉 M2 *)
    SV_MAN := SV_MAN AND (NOT PXS5);
    M1_MAN := M1_MAN AND PXS2;
    M2_MAN := M2_MAN AND PXS3;
ELSE
    SV_MAN := FALSE;
    M1_MAN := FALSE;
    M2_MAN := FALSE;
END_IF;

(*---------- 6. 運轉命令 ----------*)
M1_CMD := NORMAL AND (M1_AUTO OR M1_MAN);
M2_CMD := NORMAL AND (M2_AUTO OR M2_MAN);
M2_HI  := NORMAL AND AUTO AND M2_AUTO AND PXS4;       (* 自動 S4 以上 100% *)
SV_CMD := (NORMAL AND AUTO AND (NOT SV_OFF)) OR SV_MAN;

T_M1(IN := M1_CMD, PT := T#3s);                       (* 緩啟動 3 秒 *)

(*---------- 7. 水位訊息碼 ----------*)
LV := 0;
IF PXS1 THEN LV := 1; END_IF;
IF PXS2 THEN LV := 2; END_IF;
IF PXS3 THEN LV := 3; END_IF;
IF PXS4 THEN LV := 4; END_IF;
IF PXS5 THEN LV := 5; END_IF;
IF PXS6 THEN LV := 6; END_IF;

(*---------- 8. 輸出 ----------*)
MC1       := RUN;                       (* 異常時保持，以便監控過載接點 *)
MC2       := RUN;

SMC_START := M1_CMD;                    (* M1 經緩啟動器 *)
INV_FWD   := M2_CMD;                    (* M2 經變頻器 *)
INV_SPS   := M2_CMD AND (NOT M2_HI);    (* 低速 40%，S4 以上自動模式切高速 *)

PL1 := M1_CMD AND (T_M1.Q OR SM412);                 (* 啟動 3 秒閃爍，之後恆亮 *)
PL2 := M2_CMD AND (M2_HI OR M2_MAN OR SM412);        (* 自動 40% 閃爍；100% 或手動恆亮 *)
PL3 := SV_CMD;                                       (* 以 PL3 代替 SV *)
SV  := SV_CMD;                                       (* SV 實際輸出位置（I/O 圖標示用，不配線） *)

(* 訊息碼：1=PL6、2=PL5、3=PL5+PL6、4=PL4、5=PL4+PL6、6=PL4+PL5 *)
PL4 := (CODE_EN AND (LV >= 4))                             OR (FAULT AND SM412);
PL5 := (CODE_EN AND ((LV = 2) OR (LV = 3) OR (LV = 6)))    OR (FAULT AND SM412);
PL6 := (CODE_EN AND ((LV = 1) OR (LV = 3) OR (LV = 5)))    OR (FAULT AND SM412);

(* BZ：自動 S5 以上斷續響；過載異常持續響，過載接點復歸即停 *)
BZ := (NORMAL AND AUTO AND PXS5 AND (NOT BZ_SIL) AND SM412)
      OR (OLF AND OL_NOW);

(*---------- 9. 更新按鈕前次狀態（放在程式最後）----------*)
PB1_OLD := PB1;
PB2_OLD := PB2;
PB3_OLD := PB3;
PB4_OLD := PB4;
PB5_OLD := PB5;
```

---

## 4. 動作對照（自動模式，COS 切 2，按 PB1 後）

| 水位事件 | 訊息碼 | 程式行為 |
| --- | --- | --- |
| 上升至 S1 | 1 (PL6) | `LV=1`，M1、M2 不動作 |
| 上升至 S2 | 2 (PL5) | `M1_AUTO` 置位 → SMC_START；PL1 閃 3 秒後恆亮 |
| 上升至 S3 | 3 (PL5、PL6) | `M2_AUTO` 置位 → INV_FWD + INV_SPS（40%）；PL2 閃爍 |
| 上升至 S4 | 4 (PL4) | `M2_HI` → INV_SPS OFF（100%）；PL2 恆亮 |
| 上升至 S5 | 5 (PL4、PL6) | BZ 斷續響，PB5 可消音 |
| 上升至 S6 | 6 (PL4、PL5) | `SV_OFF` 置位，PL3 熄 |
| 下降低於 S6 | 5 | 維持 SV 關閉 |
| 下降低於 S5 | 4 | BZ 停響，`SV_OFF` 復位，PL3 亮 |
| 下降低於 S4 | 3 | M2 回 40%，PL2 閃爍 |
| 下降低於 S3 | 2 | 無動作（M2 繼續） |
| 下降低於 S2 | 1 | `M2_AUTO` 復位，M2 停、PL2 熄 |
| 下降低於 S1 | 0 | `M1_AUTO` 復位，M1 停、PL1 熄 |

---

## 5. 設計假設（請依檢定場地實際配線確認）

1. **近接開關**：水位到達時輸入為 ON。NPN／PNP 型請依場地切換輸入共同點極性，程式不需改。
2. **過載接點**：緩啟動器與變頻器都用 Tc-Tb（正常 ON、異常 OFF）接入 X16、X17，接點線路切斷等同跳脫。
3. **緊急停止**：PB6 接 NC 接點到 X5，按下或斷線時 X5 為 OFF。
4. **變頻器 SPS 端子**：假設 SPS 與 COM 導通（ON）為低速 40%、OFF 為高速 100%。若場地變頻器參數相反，只要把 `INV_SPS := M2_CMD AND (NOT M2_HI);` 改成 `INV_SPS := M2_CMD AND M2_HI;`。
5. **訊息碼顯示時機**（已依規格修正）：COS 在 1 或 2 且無異常時，PL4～PL6 即顯示水位碼，不需先按 PB1。依據：規格檢定表在 EMS／過載復歸並按 PB5 後（尚未再按 PB1，MC 已斷開）仍要求顯示水位碼。COS 在 0 或異常期間（PL4～PL6 同步閃爍）不顯示水位碼。
6. **異常期間**：MC1、MC2 保持 ON 以監控過載接點，M1、M2、SV 立即停止。按 PB5 復歸後 MC 才斷開，需再按 PB1 依水位重新運轉。
7. **異常復歸後的水位判斷**：自動模式的 `M1_AUTO`、`M2_AUTO`、`SV_OFF` 在異常期間仍隨水位更新，所以復歸後按 PB1 能照水位接續（例如高於 S3 時 M1 運轉、M2 40%、SV ON）。
8. **手動互鎖**：SV 在 S5 以上自動關閉；M1 低於 S2、M2 低於 S3 時自動停止（防空轉）。
9. **過載監控延遲**：MC 吸入後 1 秒才開始判斷過載（`T_OLEN`），避免緩啟動器、變頻器上電瞬間接點尚未閉合造成誤跳。
10. **PB6 動作時機**：只要 COS 在 1 或 2 就有效（不需先按 PB1）。COS 在 0 時按鈕與異常都無作用。

---

## 6. 依規格書驗證結果

將本程式邏輯逐掃描移植後，依規格書「功能部分」檢定表逐步驗證（涵蓋自動貳 (1)(2)、手動 SV／M1／M2、停機、過載）。

| 項目 | 原程式 | 修正後 |
| --- | --- | --- |
| 自動 12 個水位步驟、BZ 消音／重響、SV 關閉／重開 | 符合 | 符合 |
| EMS／過載 PL4～6 閃爍、BZ 持續響至接點復歸 | 符合 | 符合 |
| 復歸後 PB1 依水位接續（M1 運轉、M2 40%、SV ON） | 符合 | 符合 |
| 手動 SV／M1／M2 互鎖、PL1 閃 3 秒、PB 切換 | 符合 | 符合 |
| COS 切 0 全部 OFF、PB1 無作用 | 符合 | 符合 |
| 異常復歸（PB5）後水位訊息碼顯示 | **不符** | 符合 |
| SV 輸出位置標示於 I/O 圖 | **缺漏** | 已加 Y14 |

### 修正內容

1. **訊息碼顯示條件**：原本用 `NORMAL`（含 RUN）判斷，異常復歸後 RUN 解除，PL4～PL6 全暗。規格檢定表在下列步驟要求仍顯示水位碼：貳 (2) 步驟 19（PL5、PL6）、肆 步驟 7（PL5、PL6）、伍 步驟 7（PL4、PL6）、柒 步驟 5、9（PL4、PL6）。改用新增的 `CODE_EN := MODE_ON AND (NOT FAULT)`。
2. **SV 輸出位置**：規格 六 要求 I/O 圖標示 SV 輸出，新增 `SV`（Y14），與 PL3 同步動作，不必配線。

### 仍需依現場確認的項目（規格書文字無法判定）

- **INV_SPS 極性**：高低速端子動作邏輯在示意圖，文字未寫明，見假設 4。
- **手動 SV 於水位升到 S5 時自動關閉**：規格只寫「低於 S5 才能啟動放水」。目前比照 M1、M2 的防空轉互鎖，水位到 S5 即關閉 SV。若評分者認為 SV 開啟後應維持到再按 PB2，把 `SV_MAN := SV_MAN AND (NOT PXS5);` 刪除即可。
- **過載監控**：MC 吸入 1 秒後，只要 RUN 為 ON 就監控兩個過載接點，不限該馬達是否運轉。
