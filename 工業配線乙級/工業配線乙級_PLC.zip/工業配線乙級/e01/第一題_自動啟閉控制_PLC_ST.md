# 第一題 自動啟閉控制 — 三菱 PLC ST 程式

> 依《第一題_自動啟閉控制.docx》規格書生成。語法為 IEC 61131-3 Structured Text（GX Works3 / iQ-F FX5U 風格）。
> I/O 位址為本程式自行分配，可依實際接線調整（TB-40P 僅規定面板端子，PLC 端未指定）。

---

## 1. 設計重點與假設

| 項目 | 處理方式 |
|---|---|
| 啟動順序 | PB2 → M1 立即；5 s 後 M2；再 10 s 後 M3。啟動中 PL4 以 1 Hz 閃爍，M3 加入後 PL4 恆亮 |
| PB1 清除殘留物 | M1、M2、M3 全部運轉；5 s 後 M1 停 → 10 s 後 M2 停 → 5 s 後 M3 停。各階段 PL4 與該段 PL 交互閃爍 |
| 過載（TH） | 跳脫的電動機及較早啟動者立即停止，較晚者依 10 s／5 s 流程停止（與 PB1 後段共用同一組停機流程） |
| M1、M2 運轉中 TH1 跳脫 | M1 立即停；M2 再運轉 10 s；M3 沿用跳脫前 M2 已累計的計時（合計 10 s）後啟動，並於 M2 停止 5 s 後停止 |
| EMO（PB6） | 經安全電驛，不直接進 PLC。電驛輸出 K1、K2 接點兩者皆閉合才視為正常；任一斷開即視為 EMO |
| EMO 動作時 | 電動機全停、PL1/2/3/5 全熄、PL4 恆亮、BZ 0.5 s ON／0.5 s OFF；所有計時暫停並保留 |
| EMO 復歸 | 栓鎖解除且電驛復歸（K1、K2 皆閉合）→ BZ 停響；按 PB2 才恢復原動作並延續剩餘計時 |
| 啟動檢查（備援性） | 由安全電驛硬體的 Off check 完成；若有接點未復歸，K1、K2 不會閉合，PLC 持續 BZ 閃爍、PB2 無作用 |
| TH 接線 | 使用 TH 的 b 接點（NC）進 PLC，迴路斷線等同跳脫 |
| PL1、PL2、PL3 | PLC 輸出接點須與 MC1、MC2、MC3 輔助 a 接點串聯後才接燈，不由 PLC 直接控制（見第 3 節） |
| COS | 位置 1 才接受 PB1、PB2；位置 2 時 BZ 測試。有警報時 COS 切 2 使 BZ 停響 |

### 規格未明訂，程式採用的處理

1. 清除流程（PB1）進行中，PB1、PB2 不動作。
2. 過載流程進行中，或任一 TH 仍跳脫時，PB1、PB2 不動作（對應功能表陸-8、陸-9、拾-2）。
3. TH3 跳脫一律全部停止；TH2 跳脫時若 M3 尚未運轉，M3 不再啟動；單機運轉時 TH 跳脫只停該機。
4. 待機狀態下按 PB6 也會使 BZ 閃爍、燈熄，電驛復歸後自動恢復（無運轉可恢復，不需 PB2）。
5. `Y_SAFE_START`（送安全電驛的 START）於 PLC RUN 時持續輸出。若實際電驛需脈衝啟動，請改為脈衝輸出。
6. 1 s 時鐘 SM412、0.1 s 時鐘 SM410 為 iQ-F／iQ-R 特殊繼電器。若使用 FX3U，請改為 M8013（1 s）與 M8012（0.1 s）。

---

## 2. I/O 分配

### 輸入

| 位址 | 標籤 | 說明 | 接點 |
|---|---|---|---|
| X0 | `X_PB1` | 停止按鈕 PB1（清除殘留物） | NO |
| X1 | `X_PB2` | 啟動按鈕 PB2 | NO |
| X2 | `X_COS_NC` | COS 位置 1 | NC |
| X3 | `X_COS_NO` | COS 位置 2 | NO |
| X4 | `X_TH1_OK` | 積熱電驛 TH1 | NC（1＝正常） |
| X5 | `X_TH2_OK` | 積熱電驛 TH2 | NC（1＝正常） |
| X6 | `X_TH3_OK` | 積熱電驛 TH3 | NC（1＝正常） |
| X7 | `X_K1` | 安全電驛輸出 K1 | NO（1＝正常） |
| X10 | `X_K2` | 安全電驛輸出 K2 | NO（1＝正常） |

### 輸出

| 位址 | 標籤 | 說明 |
|---|---|---|
| Y0 | `Y_MC1` | MC1（M1 電動機） |
| Y1 | `Y_MC2` | MC2（M2 電動機） |
| Y2 | `Y_MC3` | MC3（M3 電動機） |
| Y3 | `Y_PL1` | PL1 閘控（與 MC1 輔助 a 接點串聯） |
| Y4 | `Y_PL2` | PL2 閘控（與 MC2 輔助 a 接點串聯） |
| Y5 | `Y_PL3` | PL3 閘控（與 MC3 輔助 a 接點串聯） |
| Y6 | `Y_PL4` | PL4 電源指示 |
| Y7 | `Y_PL5` | PL5 過載指示 |
| Y10 | `Y_BZ` | 蜂鳴器 |
| Y11 | `Y_SAFE_START` | 送安全電驛 START |

---

## 3. 現場接線註記

- **PB6（EMO，2b）**：兩組 b 接點接安全電驛的兩個通道，CB1 並接 NC1、CB2 串接 NC2 作為故障模擬。PB6 不直接接 PLC。
- **安全電驛輸出**：K1、K2 的 NO 接點各接 PLC 一個輸入（X7、X10）。
- **PL1～PL3 燈迴路**：`PLC Y3/Y4/Y5 接點` 串聯 `MC1/MC2/MC3 輔助 a 接點` → 燈。燈亮代表接觸器確實吸合，閃爍也由 Y 接點在串聯迴路中斷續。
- **PL4、PL5、BZ**：由 PLC 輸出接點控制。

---

## 4. 標籤宣告

### 全域標籤（對應 I/O）

見第 2 節，類型皆為 `Bit`。

### 區域標籤

| 標籤 | 類型 | 初值 | 說明 |
|---|---|---|---|
| `SEQ` | INT | 0 | 流程步驟（見第 6 節） |
| `HOLD` | BOOL | FALSE | EMO 暫停鎖定（等待 PB2 恢復） |
| `OL_ACT` | BOOL | FALSE | 過載停機流程進行中 |
| `M3_PEND` | BOOL | FALSE | M3 啟動待命（沿用跳脫前計時） |
| `cTS2` | UINT | 0 | 啟動：M1→M2 計時（0.1 s） |
| `cTS3` | UINT | 0 | 啟動：M2→M3 計時（0.1 s） |
| `cTD1` | UINT | 0 | 停機：→M1 停止計時（0.1 s） |
| `cTD2` | UINT | 0 | 停機：M1 停→M2 停計時（0.1 s） |
| `cTD3` | UINT | 0 | 停機：M2 停→M3 停計時（0.1 s） |
| `PB1_TRG`、`PB2_TRG`、`TICK_TRG` | R_TRIG | — | 上升緣偵測 |
| `PB1_P`、`PB2_P`、`TICK` | BOOL | — | 上升緣脈波 |
| `TH1_OK`、`TH2_OK`、`TH3_OK`、`TH_ANY` | BOOL | — | TH 狀態（`TH_ANY`＝任一跳脫） |
| `SAFE_OK`、`COS1`、`COS2`、`CLK1` | BOOL | — | 安全電驛正常、COS 位置、1 Hz 時鐘 |
| `EN_CMD`、`CMD_START`、`CMD_CLEAN` | BOOL | — | 操作許可與指令 |
| `RUN_EN`、`TMR_EN` | BOOL | — | 運轉許可、計時許可 |
| `R1`、`R2`、`R3` | BOOL | — | 電動機運轉命令 |
| `MC1_ON`、`MC2_ON`、`MC3_ON` | BOOL | — | 電動機實際輸出 |
| `ALT`、`STARTING`、`ALARM` | BOOL | — | 燈號與警報輔助旗標 |

### 常數

| 標籤 | 值 | 標籤 | 值 |
|---|---|---|---|
| `C_IDLE` | 0 | `C_SD1` | 4 |
| `C_ST1` | 1 | `C_SD2` | 5 |
| `C_ST2` | 2 | `C_SD3` | 6 |
| `C_RUN` | 3 | | |

---

## 5. ST 程式

```pascal
(*==================================================================
  第一題 自動啟閉控制
  時基：TICK ＝ 0.1 s，5 s ＝ 50，10 s ＝ 100
==================================================================*)

(*---------- 1. 輸入整理 ----------*)
TH1_OK  := X_TH1_OK;                 (* NC 接點：1＝正常，斷線＝0＝跳脫 *)
TH2_OK  := X_TH2_OK;
TH3_OK  := X_TH3_OK;
TH_ANY  := NOT (TH1_OK AND TH2_OK AND TH3_OK);

SAFE_OK := X_K1 AND X_K2;            (* 安全電驛 K1、K2 皆閉合才正常 *)
COS1    := X_COS_NC;                 (* COS 位置 1 *)
COS2    := X_COS_NO;                 (* COS 位置 2 *)

PB1_TRG(CLK := X_PB1);  PB1_P := PB1_TRG.Q;
PB2_TRG(CLK := X_PB2);  PB2_P := PB2_TRG.Q;
TICK_TRG(CLK := SM410); TICK  := TICK_TRG.Q;   (* 每 0.1 s 一個脈波 *)
CLK1    := SM412;                    (* 1 Hz：ON 0.5 s / OFF 0.5 s *)

(*---------- 2. 操作許可與 EMO 暫停 ----------*)
(* PB1、PB2 許可：COS 在 1、安全電驛正常、非暫停、無 TH 跳脫、非過載流程中 *)
EN_CMD    := COS1 AND SAFE_OK AND (NOT HOLD) AND (NOT TH_ANY) AND (NOT OL_ACT);
CMD_CLEAN := PB1_P AND EN_CMD;
CMD_START := PB2_P AND EN_CMD;

(* 暫停解除：電驛已復歸（K1、K2 閉合）後按 PB2，該次 PB2 只用於恢復 *)
IF HOLD AND SAFE_OK AND PB2_P THEN
    HOLD := FALSE;
END_IF;

(* EMO 動作：流程進行中則鎖定，保留步驟與剩餘計時 *)
IF (NOT SAFE_OK) AND (SEQ <> C_IDLE) THEN
    HOLD := TRUE;
END_IF;

RUN_EN := SAFE_OK AND (NOT HOLD);    (* 電動機與燈號輸出許可 *)
TMR_EN := TICK AND RUN_EN;           (* 計時許可：暫停時計時值保留 *)

(*---------- 3. PB1 / PB2 指令 ----------*)
IF CMD_CLEAN THEN
    (* 運轉中（不論啟動完成與否）或停車狀態下皆可 *)
    IF (SEQ = C_IDLE) OR (SEQ = C_ST1) OR (SEQ = C_ST2) OR (SEQ = C_RUN) THEN
        SEQ := C_SD1;  cTD1 := 0;  M3_PEND := FALSE;
    END_IF;
ELSIF CMD_START THEN
    IF SEQ = C_IDLE THEN
        SEQ := C_ST1;  cTS2 := 0;  cTS3 := 0;
    END_IF;
END_IF;

(*---------- 4. 過載（TH）處理：以準位判斷，TH3 > TH2 > TH1 ----------*)
IF NOT TH3_OK THEN
    (* TH3 跳脫：所有電動機立即停止 *)
    IF SEQ <> C_IDLE THEN
        SEQ := C_IDLE;
    END_IF;

ELSIF NOT TH2_OK THEN
    (* TH2 跳脫：M1、M2 立即停止；M3 若在運轉則 5 s 後停止 *)
    IF (SEQ = C_ST1) OR (SEQ = C_ST2) THEN
        SEQ := C_IDLE;                           (* M3 尚未運轉，不再啟動 *)
    ELSIF (SEQ = C_RUN) OR (SEQ = C_SD1) THEN
        SEQ := C_SD3;  cTD3 := 0;  OL_ACT := TRUE;
    ELSIF SEQ = C_SD2 THEN
        IF M3_PEND THEN
            SEQ := C_IDLE;                       (* M3 待命中，取消啟動 *)
        ELSE
            SEQ := C_SD3;  cTD3 := 0;  OL_ACT := TRUE;
        END_IF;
    END_IF;

ELSIF NOT TH1_OK THEN
    (* TH1 跳脫：M1 立即停止；M2 再運轉 10 s；M3 再 5 s *)
    IF SEQ = C_ST1 THEN
        SEQ := C_IDLE;                           (* 單機運轉：只停 M1 *)
    ELSIF SEQ = C_ST2 THEN
        (* M1、M2 運轉：M3 沿用跳脫前計時 cTS3 繼續累計 *)
        SEQ := C_SD2;  M3_PEND := TRUE;  cTD2 := 0;  OL_ACT := TRUE;
    ELSIF (SEQ = C_RUN) OR (SEQ = C_SD1) THEN
        SEQ := C_SD2;  M3_PEND := FALSE;  cTD2 := 0;  OL_ACT := TRUE;
    END_IF;
END_IF;

(*---------- 5. 流程計時與步進 ----------*)
IF SEQ = C_ST1 THEN                              (* M1 運轉，等 5 s *)
    IF TMR_EN THEN cTS2 := cTS2 + 1; END_IF;
    IF cTS2 >= 50 THEN
        SEQ := C_ST2;  cTS3 := 0;
    END_IF;

ELSIF SEQ = C_ST2 THEN                           (* M1、M2 運轉，等 10 s *)
    IF TMR_EN THEN cTS3 := cTS3 + 1; END_IF;
    IF cTS3 >= 100 THEN
        SEQ := C_RUN;
    END_IF;

ELSIF SEQ = C_SD1 THEN                           (* 全部運轉，5 s 後 M1 停 *)
    IF TMR_EN THEN cTD1 := cTD1 + 1; END_IF;
    IF cTD1 >= 50 THEN
        SEQ := C_SD2;  cTD2 := 0;
    END_IF;

ELSIF SEQ = C_SD2 THEN                           (* M1 已停，10 s 後 M2 停 *)
    IF TMR_EN THEN
        cTD2 := cTD2 + 1;
        IF M3_PEND THEN cTS3 := cTS3 + 1; END_IF;
    END_IF;
    IF M3_PEND AND (cTS3 >= 100) THEN
        M3_PEND := FALSE;                        (* 合計 10 s 到，M3 開始運轉 *)
    END_IF;
    IF cTD2 >= 100 THEN
        SEQ := C_SD3;  cTD3 := 0;
    END_IF;

ELSIF SEQ = C_SD3 THEN                           (* M1、M2 已停，5 s 後 M3 停 *)
    IF TMR_EN THEN cTD3 := cTD3 + 1; END_IF;
    IF cTD3 >= 50 THEN
        SEQ := C_IDLE;
    END_IF;
END_IF;

IF SEQ = C_IDLE THEN
    OL_ACT  := FALSE;
    M3_PEND := FALSE;
END_IF;

(*---------- 6. 電動機運轉命令 ----------*)
R1 := FALSE;  R2 := FALSE;  R3 := FALSE;

IF SEQ = C_ST1 THEN
    R1 := TRUE;
ELSIF SEQ = C_ST2 THEN
    R1 := TRUE;  R2 := TRUE;
ELSIF (SEQ = C_RUN) OR (SEQ = C_SD1) THEN
    R1 := TRUE;  R2 := TRUE;  R3 := TRUE;
ELSIF SEQ = C_SD2 THEN
    R2 := TRUE;  R3 := NOT M3_PEND;
ELSIF SEQ = C_SD3 THEN
    R3 := TRUE;
END_IF;

(* 輸出：EMO／暫停時全停；TH 跳脫的電動機硬性切離 *)
MC1_ON := R1 AND RUN_EN AND TH1_OK;
MC2_ON := R2 AND RUN_EN AND TH2_OK;
MC3_ON := R3 AND RUN_EN AND TH3_OK;

Y_MC1 := MC1_ON;
Y_MC2 := MC2_ON;
Y_MC3 := MC3_ON;

(*---------- 7. 指示燈 ----------*)
ALT      := (SEQ = C_SD1) OR (SEQ = C_SD2) OR (SEQ = C_SD3);   (* 與 PL4 交互閃爍 *)
STARTING := (SEQ = C_ST1) OR (SEQ = C_ST2);                    (* PL4 閃爍 *)

(* PL1～PL3：Y 接點再串 MC 輔助 a 接點（現場接線），此處為閘控訊號 *)
Y_PL1 := MC1_ON AND ((SEQ <> C_SD1) OR CLK1);
Y_PL2 := MC2_ON AND ((SEQ <> C_SD2) OR CLK1);
Y_PL3 := MC3_ON AND ((SEQ <> C_SD3) OR CLK1);

IF NOT RUN_EN THEN
    Y_PL4 := TRUE;                               (* EMO／暫停：PL4 除外全熄 *)
ELSIF ALT THEN
    Y_PL4 := NOT CLK1;                           (* 與 PL1/2/3 交互閃爍 *)
ELSIF STARTING THEN
    Y_PL4 := CLK1;                               (* 啟動中閃爍 *)
ELSE
    Y_PL4 := TRUE;                               (* 電源指示 *)
END_IF;

Y_PL5 := TH_ANY AND RUN_EN;                      (* 任一 TH 跳脫 *)

(*---------- 8. 蜂鳴器 ----------*)
ALARM := TH_ANY OR OL_ACT;                       (* 過載警報：TH 跳脫或過載流程中 *)

IF NOT SAFE_OK THEN
    Y_BZ := CLK1;                                (* EMO 動作／未復歸：0.5 s ON / 0.5 s OFF *)
ELSIF HOLD THEN
    Y_BZ := FALSE;                               (* 栓鎖已解除，等待 PB2 *)
ELSE
    Y_BZ := ALARM XOR COS2;                      (* 警報響，COS 切 2 停響；無警報時 COS 切 2 為測試 *)
END_IF;

(*---------- 9. 安全電驛 START ----------*)
Y_SAFE_START := TRUE;
```

---

## 6. 流程步驟（`SEQ`）

| `SEQ` | 名稱 | M1 | M2 | M3 | 燈號 | 離開條件 |
|---|---|---|---|---|---|---|
| 0 | `C_IDLE` 待機 | – | – | – | PL4 亮 | PB2 → 1；PB1 → 4 |
| 1 | `C_ST1` 啟動 1 | ON | – | – | PL1 亮、PL4 閃 | 5 s → 2 |
| 2 | `C_ST2` 啟動 2 | ON | ON | – | PL1、PL2 亮、PL4 閃 | 10 s → 3 |
| 3 | `C_RUN` 運轉 | ON | ON | ON | PL1～PL4 亮 | PB1 → 4 |
| 4 | `C_SD1` 清除 1 | ON | ON | ON | PL2、PL3 亮；PL1／PL4 交互閃 | 5 s → 5 |
| 5 | `C_SD2` 清除 2 | – | ON | ON | PL3 亮；PL2／PL4 交互閃 | 10 s → 6 |
| 6 | `C_SD3` 清除 3 | – | – | ON | PL3／PL4 交互閃 | 5 s → 0 |

`SEQ` 5 搭配 `M3_PEND = TRUE` 時，M3 尚未啟動（M1、M2 運轉中 TH1 跳脫），待 `cTS3` 累計到 10 s 才加入。

---

## 7. 規格對照（功能部分抽查）

| 規格情境 | 程式行為 |
|---|---|
| 壹-5、6、7：PL4 亮；COS 切 2 時 BZ 響；切回 1 停響 | 待機 PL4 恆亮；`Y_BZ := ALARM XOR COS2` |
| 貳：PB2 全程啟動；PB1 清除 | `SEQ` 0→1→2→3；PB1 走 4→5→6→0 |
| 參、肆：啟動中或停車時按 PB1 | `CMD_CLEAN` 於 0、1、2、3 皆接受，M1～M3 同時運轉後依序停止 |
| 伍：EMO 後按 PB2 延續計時 | `HOLD` 保留 `SEQ` 與計時值；K1、K2 復歸後 PB2 恢復 |
| 陸-1：TH1 跳脫（三機運轉） | `SEQ` 3→5；M1 停，10 s M2 停，5 s M3 停；PL5、BZ 持續 |
| 陸-4：清除中 TH2 跳脫 | `SEQ` 4→6；M1、M2 立即停，M3 5 s 後停 |
| 陸-7～9：TH3 跳脫，PB1、PB2 無作用 | `SEQ`→0；`TH_ANY` 使 `EN_CMD` 為 FALSE |
| 柒-2：M1、M2 運轉時 TH1 跳脫 | `SEQ` 2→5，`M3_PEND`；M2 再運轉 10 s，M3 合計 10 s 後加入，M2 停後 5 s M3 停 |
| 柒-3、4：COS 切 2 → TH 復歸 | COS 切 2 時 BZ 停響、PL5 亮；TH 復歸後 PL5 熄，BZ 因 COS 測試而響；COS 切 1 後停響 |
| 拾-2：TH1 跳脫後立即復歸，PB1、PB2 無作用 | `OL_ACT` 為 TRUE，流程結束前 BZ 持續、PL5 熄、PB 無作用；結束後 PL4 亮、BZ 停 |
| 拾壹：EMO 備援性與啟動檢查 | 任一通道未復歸時 K1／K2 不閉合 → `SAFE_OK` 為 FALSE → BZ 閃爍、PB2 無作用；完全復歸後 BZ 停，按 PB2 重新啟動 |
