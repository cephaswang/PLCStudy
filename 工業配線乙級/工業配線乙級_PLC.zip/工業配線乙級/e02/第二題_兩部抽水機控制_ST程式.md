# 第二題　兩部抽水機控制 — 三菱 PLC ST 程式

> 適用：GX Works3（FX5U / iQ-R 皆可，示例以 FX5U 軟元件編號撰寫）
> 圖面未提供 I/O 配置表，下列點位為自行定義，實際接線請依現場調整。

---

## 1. I/O 配置

### 1.1 實體輸入 (X)

| 標籤 | 位址 | 說明 | 接點 / 邏輯 |
|---|---|---|---|
| `EMS_NC` | X0 | 緊急停止開關 | 1b：正常 ON，按下/斷線 = OFF |
| `TH1_NC` | X1 | 積熱電驛 TH1 | 1b：正常 ON，跳脫/斷線 = OFF |
| `TH2_NC` | X2 | 積熱電驛 TH2 | 1b：正常 ON，跳脫/斷線 = OFF |
| `TW_LOW_LS` | X3 | 水塔下水位浮球 | N.O.：ON = 水位高於低水位，OFF = 缺水 |
| `TW_HIGH_LS` | X4 | 水塔上水位浮球 | N.O.：ON = 滿水（高水位） |
| `POOL_LS` | X5 | 蓄水池切換開關 (1a) | ON = 高於低水位，OFF = 低水位 |
| `MC1_FB` | X6 | MC1 輔助 a 接點（回授） | MC1 吸合 = ON |
| `MC2_FB` | X7 | MC2 輔助 a 接點（回授） | MC2 吸合 = ON |

### 1.2 實體輸出 (Y)

| 標籤 | 位址 | 說明 |
|---|---|---|
| `MC1` | Y0 | #1 抽水機電磁接觸器 |
| `MC2` | Y1 | #2 抽水機電磁接觸器 |
| `BZ` | Y2 | 過載警報蜂鳴器 |

### 1.3 HMI 軟元件 (M / D)

HMI 的元件顏色規則：位元 ON = 紅色、OFF = 綠色。

| 標籤 | 位址 | 方向 | 說明 |
|---|---|---|---|
| `HMI_PB1` | M0 | HMI→PLC | 警報 OFF 按鈕（瞬時） |
| `HMI_PB2` | M1 | HMI→PLC | 手動操作按鈕（瞬時） |
| `HMI_COS` | M2 | HMI→PLC | COS 切換觸控鍵（瞬時，每觸一次換一檔） |
| `HMI_PL1` | M10 | PLC→HMI | #1 機運轉 |
| `HMI_PL2` | M11 | PLC→HMI | #2 機運轉 |
| `HMI_PL3` | M12 | PLC→HMI | #1 機過載 |
| `HMI_PL4` | M13 | PLC→HMI | #2 機過載 |
| `HMI_PL5` | M14 | PLC→HMI | 蓄水池（ON = 低水位，不允許抽水） |
| `HMI_PL6` | M15 | PLC→HMI | 水塔缺水 |
| `HMI_EMS` | M16 | PLC→HMI | EMS 指示燈 |
| `nCosIdx` | D100 | **保持型** | COS 檔位順序索引（0→1 檔，1→0 檔，2→2 檔，3→0 檔） |
| `HMI_COS_POS` | D101 | PLC→HMI | COS 目前檔位（0 / 1 / 2），供 HMI 旋鈕圖示顯示 |

> **D100 必須設為閂鎖 (Latch) 範圍**，才能滿足「PLC 重新啟動後 COS 檔位保持」。
> FX5U：CPU 參數 → 軟元件/標籤記憶體 → 閂鎖範圍設定。

---

## 2. 區域標籤（Local Label）

| 標籤 | 型態 | 說明 |
|---|---|---|
| `bEMS` `bTH1Trip` `bTH2Trip` | BOOL | 轉換後的邏輯訊號（TRUE = 動作） |
| `bTowerLow` `bTowerHigh` `bPoolLow` | BOOL | 水塔缺水 / 水塔滿水 / 蓄水池低水位 |
| `bPB1` `bPB2` `bCosTouch` | BOOL | HMI 按鍵 |
| `bEMS_p` `bTH1_p` `bTH2_p` `bPB1_p` `bPB2_p` `bCos_p` `bPoolLow_p` `bThLock_p` `bRun_p` | BOOL | 前一掃描值（邊緣偵測） |
| `bTH1Rise` `bTH2Rise` `bPB1Rise` `bPB2Rise` `bCosRise` `bEMSFall` `bPoolLowRise` `bThLockClr` | BOOL | 邊緣脈波 |
| `bFault` | BOOL | 輸出確認故障（只能靠重啟 PLC 解除） |
| `bThBlock` | BOOL | 啟動 / EMS 解除時 TH 未復歸，閃爍顯示且禁止運轉 |
| `bBothLock` | BOOL | 兩台 TH 皆跳脫，須兩台都復歸才恢復 |
| `bThLock` | BOOL | `bBothLock OR bThBlock`，禁止抽水機運轉 |
| `bBz10` `bBzSilence` `bBzOn` | BOOL | 蜂鳴器控制 |
| `bRun` `bRunOK` `bGo` | BOOL | 抽水需求 / 允許運轉 / 輸出條件 |
| `bCmdMC1` `bCmdMC2` | BOOL | MC 輸出命令 |
| `bBlink` | BOOL | 0.5 s ON / 0.5 s OFF 閃爍脈波 |
| `nCos` `nCosPrev` `nCur` | INT | COS 檔位 / 前次檔位 / 目前（下次）運轉的抽水機（1 或 2） |
| `tBlk1` `tBlk2` `tBz10` `tMc1Err` `tMc2Err` | TON | 計時器 FB |

---

## 3. ST 程式

```pascal
//==========================================================================
// 第二題 兩部抽水機控制
//==========================================================================

//--------------------------------------------------------------------------
// 0. 0.5 秒閃爍產生器 (ON 0.5s / OFF 0.5s)
//--------------------------------------------------------------------------
tBlk1(IN := NOT tBlk2.Q, PT := T#500ms);
tBlk2(IN := tBlk1.Q,     PT := T#500ms);
bBlink := tBlk1.Q;

//--------------------------------------------------------------------------
// 1. 輸入邏輯轉換（極性只在此處修改）
//--------------------------------------------------------------------------
bEMS       := NOT EMS_NC;       // EMS 按下或斷線
bTH1Trip   := NOT TH1_NC;       // TH1 跳脫或斷線
bTH2Trip   := NOT TH2_NC;       // TH2 跳脫或斷線
bTowerLow  := NOT TW_LOW_LS;    // 水塔缺水（低水位）
bTowerHigh := TW_HIGH_LS;       // 水塔滿水（高水位）
bPoolLow   := NOT POOL_LS;      // 蓄水池低水位
bPB1       := HMI_PB1;
bPB2       := HMI_PB2;
bCosTouch  := HMI_COS;

//--------------------------------------------------------------------------
// 2. 初始化（PLC 啟動第一個掃描）
//    非保持型狀態全部清除，COS 檔位 (D100) 保持不動
//--------------------------------------------------------------------------
IF SM402 THEN
    bFault := FALSE;     bRun := FALSE;       bRun_p := FALSE;
    nCur := 1;
    bThBlock := FALSE;   bBothLock := FALSE;  bThLock_p := FALSE;
    bBz10 := FALSE;      bBzSilence := FALSE;
    bCmdMC1 := FALSE;    bCmdMC2 := FALSE;
    // 前一掃描值 = 現值，避免啟動瞬間誤判邊緣
    bEMS_p := bEMS;      bTH1_p := bTH1Trip;  bTH2_p := bTH2Trip;
    bPB1_p := bPB1;      bPB2_p := bPB2;      bCos_p := bCosTouch;
    bPoolLow_p := bPoolLow;
END_IF;

//--------------------------------------------------------------------------
// 3. 邊緣偵測
//--------------------------------------------------------------------------
bTH1Rise     := bTH1Trip AND NOT bTH1_p;
bTH2Rise     := bTH2Trip AND NOT bTH2_p;
bPB1Rise     := bPB1 AND NOT bPB1_p AND NOT bFault;
bPB2Rise     := bPB2 AND NOT bPB2_p AND NOT bFault;
bCosRise     := bCosTouch AND NOT bCos_p AND NOT bFault;
bEMSFall     := bEMS_p AND NOT bEMS;
bPoolLowRise := bPoolLow AND NOT bPoolLow_p;

//--------------------------------------------------------------------------
// 4. 輸出確認與故障判斷（故障後全部關閉，需重啟 PLC 才能解除）
//--------------------------------------------------------------------------
// (1) MC 與 PLC 輸出不同步（有輸出未吸合 / 無輸出卻吸合），持續 0.5 s 判定故障
tMc1Err(IN := (bCmdMC1 XOR MC1_FB), PT := T#500ms);
tMc2Err(IN := (bCmdMC2 XOR MC2_FB), PT := T#500ms);
IF tMc1Err.Q OR tMc2Err.Q THEN
    bFault := TRUE;
END_IF;

// (2) 馬達未運轉（上一掃描 MC 命令為 OFF），其 TH 卻動作 → 故障
IF (bTH1Rise AND NOT bCmdMC1) OR (bTH2Rise AND NOT bCmdMC2) THEN
    bFault := TRUE;
END_IF;

//--------------------------------------------------------------------------
// 5. COS 檔位（HMI 觸控切換，順序 1→0→2→0→1…，斷電保持）
//--------------------------------------------------------------------------
IF bCosRise THEN
    nCosIdx := nCosIdx + 1;
    IF nCosIdx > 3 THEN
        nCosIdx := 0;
    END_IF;
END_IF;
IF (nCosIdx < 0) OR (nCosIdx > 3) THEN
    nCosIdx := 0;
END_IF;

CASE nCosIdx OF
    0: nCos := 1;     // 自動交替
    1: nCos := 0;     // 手動交替
    2: nCos := 2;     // 緊急抽水
    3: nCos := 0;     // 手動交替
END_CASE;
HMI_COS_POS := nCos;

//--------------------------------------------------------------------------
// 6. TH 鎖定狀態
//--------------------------------------------------------------------------
// 兩台 TH 皆跳脫 → 鎖定，直到兩台都復歸
IF bTH1Trip AND bTH2Trip THEN
    bBothLock := TRUE;
END_IF;

// 啟動 / EMS 解除時仍有 TH 未復歸 → 閃爍顯示，直到全部復歸才恢復
IF (SM402 OR bEMSFall) AND (bTH1Trip OR bTH2Trip) THEN
    bThBlock := TRUE;
END_IF;

// 全部復歸 → 解除
IF (NOT bTH1Trip) AND (NOT bTH2Trip) THEN
    bBothLock := FALSE;
    bThBlock  := FALSE;
END_IF;

bThLock    := bBothLock OR bThBlock;
bThLockClr := bThLock_p AND NOT bThLock;   // 鎖定解除瞬間

//--------------------------------------------------------------------------
// 7. 抽水需求 (bRun) 與抽水機選擇 (nCur)
//--------------------------------------------------------------------------
bRunOK := (NOT bFault) AND (NOT bEMS) AND (NOT bThLock) AND (NOT bPoolLow);

// 7-1 事件重置：啟動、EMS 解除、TH 鎖定解除、COS 換檔 → 回到初始狀態（#1 優先）
IF SM402 OR bEMSFall OR bThLockClr OR (nCos <> nCosPrev) THEN
    bRun   := FALSE;
    bRun_p := FALSE;
    nCur   := 1;
END_IF;

// 7-2 蓄水池進入低水位：交替順序回到 #1，手動模式的運轉狀態清除
IF bPoolLowRise THEN
    nCur := 1;
    IF nCos = 0 THEN
        bRun   := FALSE;
        bRun_p := FALSE;
    END_IF;
END_IF;

// 7-3 依 COS 檔位決定抽水需求
CASE nCos OF
    1, 2:   // 自動 / 緊急：水塔低水位啟動，高水位停止
        IF bTowerHigh THEN
            bRun := FALSE;
        ELSIF bTowerLow THEN
            bRun := TRUE;
        END_IF;
    0:      // 手動：每按 PB2 一次，運轉 / 停止輪換（不看水塔水位）
        IF bPB2Rise AND bRunOK THEN
            bRun := NOT bRun;
        END_IF;
END_CASE;

// 7-4 一個運轉週期結束（bRun 下降緣）→ 換另一部抽水機
IF bRun_p AND (NOT bRun) THEN
    nCur := 3 - nCur;
END_IF;
bRun_p := bRun;

// 7-5 目前選到的抽水機 TH 跳脫 → 立即換另一部（兩台都跳脫時由鎖定處理）
IF NOT (bTH1Trip AND bTH2Trip) THEN
    IF (nCur = 1) AND bTH1Trip THEN
        nCur := 2;
    ELSIF (nCur = 2) AND bTH2Trip THEN
        nCur := 1;
    END_IF;
END_IF;

//--------------------------------------------------------------------------
// 8. 抽水機輸出命令
//--------------------------------------------------------------------------
bGo := bRun AND bRunOK;

IF nCos = 2 THEN
    // 緊急抽水：兩部同時運轉，TH 跳脫者除外
    bCmdMC1 := bGo AND (NOT bTH1Trip);
    bCmdMC2 := bGo AND (NOT bTH2Trip);
ELSE
    // 自動 / 手動：一次只運轉一部
    bCmdMC1 := bGo AND (nCur = 1) AND (NOT bTH1Trip);
    bCmdMC2 := bGo AND (nCur = 2) AND (NOT bTH2Trip);
END_IF;

//--------------------------------------------------------------------------
// 9. 蜂鳴器
//    - 單台 TH 跳脫：斷續響 10 秒
//    - 兩台 TH 皆跳脫：斷續響，直到按 PB1（或全部復歸）
//    - 啟動 / EMS 解除後的 TH 未復歸狀態：BZ 不響
//--------------------------------------------------------------------------
IF bTH1Rise OR bTH2Rise THEN
    bBz10 := TRUE;
END_IF;
tBz10(IN := bBz10, PT := T#10s);
IF tBz10.Q OR bPB1Rise OR bThBlock THEN
    bBz10 := FALSE;
END_IF;

IF bBothLock THEN
    IF bPB1Rise THEN
        bBzSilence := TRUE;
    END_IF;
ELSE
    bBzSilence := FALSE;
END_IF;

bBzOn := ((bBothLock AND (NOT bThBlock) AND (NOT bBzSilence)) OR bBz10)
         AND bBlink AND (NOT bFault);

//--------------------------------------------------------------------------
// 10. 實體輸出
//--------------------------------------------------------------------------
MC1 := bCmdMC1;
MC2 := bCmdMC2;
BZ  := bBzOn;

//--------------------------------------------------------------------------
// 11. HMI 指示燈（ON = 紅，OFF = 綠；故障時全部為綠）
//--------------------------------------------------------------------------
HMI_PL1 := bCmdMC1;
HMI_PL2 := bCmdMC2;

// 過載燈：一般跳脫 = 恆亮紅；啟動/EMS 解除後未復歸 = 紅燈閃爍
HMI_PL3 := bTH1Trip AND ((NOT bThBlock) OR bBlink) AND (NOT bFault);
HMI_PL4 := bTH2Trip AND ((NOT bThBlock) OR bBlink) AND (NOT bFault);

HMI_PL5 := bPoolLow  AND (NOT bFault);    // 蓄水池低水位
HMI_PL6 := bTowerLow AND (NOT bFault);    // 水塔缺水
HMI_EMS := bEMS      AND (NOT bFault);    // EMS 動作

//--------------------------------------------------------------------------
// 12. 儲存前一掃描值（務必放在程式最後）
//--------------------------------------------------------------------------
bEMS_p     := bEMS;
bTH1_p     := bTH1Trip;
bTH2_p     := bTH2Trip;
bPB1_p     := bPB1;
bPB2_p     := bPB2;
bCos_p     := bCosTouch;
bPoolLow_p := bPoolLow;
bThLock_p  := bThLock;
nCosPrev   := nCos;
```

---

## 4. 規格對照

| 規格項目 | 對應程式 |
|---|---|
| 二、自動交替（水塔低水位啟動、高水位停止，#1/#2 輪流） | §7-3（需求）、§7-4（換機） |
| 二-5/6、三-4/5 蓄水池低水位全停、恢復後從 #1 重新輪換 | `bRunOK`、§7-2 |
| 三、手動交替（每按 PB2 運轉/停止輪換，不看水塔） | §7-3 的 `0:` 分支 |
| 四、緊急抽水（兩台同時，蓄水池低水位全停、恢復後再起動） | §8 的 `nCos = 2` 分支 |
| 五-1 單台 TH 跳脫：PL3/PL4 亮紅、BZ 斷續響 10 s、該機停止 | §9、§11、§8 |
| 五-2 交替模式 TH 跳脫立即換另一部、單機抽水 | §7-5 |
| 五-3 兩台 TH 皆跳脫：兩機停、BZ 響到按 PB1、全部復歸才恢復 | `bBothLock`、§9 |
| 七-1 EMS 立即停機、EMS 燈紅/綠、解除後回初始狀態 | `bRunOK`、`bEMSFall` 重置 |
| 七-2 重啟 / EMS 解除時 TH 未復歸：PL 紅燈閃爍、BZ 不響 | `bThBlock`、§11 |
| 七-3 TH / EMS 迴路斷線視同動作 | 接點採 1b (NC) 輸入，§1 轉換 |
| 七-4 輸出確認（MC 不同步、TH 動作但馬達未運轉）→ 全部 OFF、燈全綠、操作無效 | §4 `bFault`，需重啟 PLC 解除 |
| 貳 COS 檔位 1→0→2→0→1 順序、重啟保持 | §5，`nCosIdx` 閂鎖 |

---

## 5. 假設與注意事項

1. **I/O 點位為自行定義**：圖面沒有 I/O 表，請依實際接線修改 §1 的位址對應。
2. **浮球極性**：假設浮球在水位上升時接點閉合 (ON)。若現場相反，只需改 §1 轉換區的 `NOT` 即可。
   - 水塔缺水 = `NOT TW_LOW_LS`
   - 水塔滿水 = `TW_HIGH_LS`
   - 蓄水池低水位 = `NOT POOL_LS`
3. **水塔停止條件**：依規格二-2，水塔到達高水位 (`TW_HIGH_LS`) 才停止，位於中間水位時保持原運轉狀態。
4. **TH 動作判斷**：按規格七-4(2)，TH 動作時若對應馬達未在運轉（上一掃描 MC 命令為 OFF），判定為故障。
   實體測試時，TH 跳脫應在對應抽水機運轉中進行，與檢定表的測試步驟一致。
5. **MC 回授**：MC1、MC2 各取一組輔助 a 接點接至 X6、X7；不同步判定時間設為 0.5 s，可依接觸器動作時間調整。
6. **重置時機**：啟動、EMS 解除、TH 鎖定解除、COS 換檔時，抽水順序回到 #1 優先。蓄水池低水位時，交替順序也會回到 #1。
7. **計時器**：使用 IEC 標準 `TON` 功能方塊，GX Works3 的 FX5U 與 iQ-R 皆可使用。
8. **HMI 規劃**：PB1、PB2、COS 觸控鍵分別對應 M0、M1、M2（瞬時動作）。COS 旋鈕圖示讀取 D101，並請設定 0/1/2 三種檔位圖示。
