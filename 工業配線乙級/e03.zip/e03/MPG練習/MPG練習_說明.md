# MPG 手搖輪練習專案（第三題 — 只練 MPG）

目標：正轉、反轉、呈現設定值 B / C / D。
檔案：`MPG練習_Main.st`（R08，GX Works3）、`Global_MPG練習.csv`（全域標籤）、`MPG練習_HMI.html`（HMI 畫面規劃）。

## 假設（可自行改）
- 位置單位 0.1 mm，每個刻度加 Mult（INT）。規格書沒寫刻度長度，若考題另有定義，只需改程式第 5 節。
- 倍率開關（COS2）：COS2_P1（X4）ON = ×1；COS2_P2（X5）ON = ×100；兩點都 OFF（位置0）= ×10；兩點同時 ON（異常）= ×1。
- 行程 0～400.0 mm（位置值 0～4000）。

## 全域標籤（以 Global_MPG練習.csv 為準，程式不再用其他名稱）
| 標籤 | 型別 | 軟元件 | 說明 |
|---|---|---|---|
| MPG_A / MPG_B | BOOL | X0 / X1 | 手輪 A / B 相 |
| COS2_P1 / COS2_P2 | BOOL | X4 / X5 | 倍率旋鈕 |
| HMI_HOME / HMI_SAVE | BOOL | M103 / M104 | 原點／儲存 |
| Sim_En | BOOL | M10 | 模擬模式 |
| Sim_CW / Sim_CCW | BOOL | M11 / M12 | 模擬正轉／反轉（按住＝連續轉） |
| HMI_LAMP_F / HMI_LAMP_R | BOOL | M140 / M141 | 正轉／反轉燈 |
| HMI_POS_B / C / D | INT | R121 / R122 / R123 | 設定值 B / C / D（0.1 mm） |
| HMI_POS_CUR | INT | R124 | 目前位置（0.1 mm） |
| HMI_MULT | INT | R125 | 倍率顯示（1/10/100） |
| HMI_DIR | INT | R126 | 0 無、1 正轉、2 反轉 |
| Mult | INT | — | 倍率值 |
| Set_Idx | INT | — | 下一個要存的點（0=B、1=C、2=D、3=已滿） |
| Sim_Step / Sim_Dir | INT | — | 模擬步序／方向 |
| Tick_Count | DINT | — | 淨刻度數（正轉＋、反轉－） |
| Sim_A / Sim_B | BOOL | — | 模擬 A/B 相 |
| A_Now / B_Now / A_Prev | BOOL | — | 解碼用 |
| Tick_CW / Tick_CCW | BOOL | — | 單刻度正／反脈衝 |
| Lim_Max / Lim_Min | BOOL | — | 到 400.0 mm／0 mm |
| R_Save / R_Home | R_TRIG | — | SAVE／HOME 上升緣 |

HMI 顯示 R121～R124 時：有符號 BIN16、整數 3 位、小數 1 位（4000 顯示 400.0）。

## 設定 B / C / D
1. 按 HOME：位置歸零，存點順序回到 B，已存設定值保留。
2. 轉手輪到想要的位置（倍率由 COS2 決定）。
3. 按 SAVE：依序存入 B → C → D。第四次按 SAVE 無作用。
4. 重來：先按 HOME，再存一次。

## 驗證步驟（GX Simulator3）
1. 將 Sim_En（M10）設 ON。
2. 按住 M11：HMI_POS_CUR（R124）持續增加，R126 = 1，M140 ON（正轉）。
3. 按住 M12：R124 減少，R126 = 2，M141 ON（反轉）。
4. COS2_P1 ON：每刻度 +1；COS2_P2 ON：每刻度 +100；兩個都 OFF：每刻度 +10。R125 同步變 1／100／10。
5. 位置超過 4000 停在 4000（Lim_Max ON）；低於 0 停在 0（Lim_Min ON）。
6. 轉到某位置，M104 ON 再 OFF：存入 R121（B）；再兩次存入 R122（C）、R123（D）；第四次無作用。
7. M103：位置、刻度歸零，存點順序回到 B，R121～R123 保留。

## 接實體手輪時
- Sim_En 設 OFF，A/B 來自 X0/X1，程式其餘部分不用改。
- 到模組參數把 X0、X1 所在輸入模組的響應時間調到最短（預設 10 ms 會吃掉脈波）。
- 手輪 NPN 輸出要配對輸入模組的 sink/source 接法與電壓（5 V 線驅動不能直接接 24 V 輸入）。
- 軟體掃描解碼，100 PPR、200 rpm 約 333 Hz，R08 小程式掃描時間通常夠用；要更穩請改用高速計數器或定位模組的手輪輸入。
- 方向相反時，對調 MPG_A 與 MPG_B 接線即可。

## HMI 注意
- COS2_P1、COS2_P2 對應實體輸入 X4、X5，HMI 寫入會被每次掃描覆蓋，不要在 HMI 上放這兩個按鈕。若要由 HMI 切倍率，需改用 M 位元並修改程式第 4 節。
- Sim_En 按鈕動作設「交替」；HOME、SAVE、Sim_CW、Sim_CCW 設「瞬時」。

## 已知限制
- 方向燈保持「最後一次方向」，不會因停止轉動而熄滅。
- Set_Idx 在 HOME 時歸零（用來重新排存點順序），不代表設定值被清除。
- .st 為 UTF-8（含 BOM）。若 GX Works3 匯入後註解亂碼，請告訴我，我改編碼。
