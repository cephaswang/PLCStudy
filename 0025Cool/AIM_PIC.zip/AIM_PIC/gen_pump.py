#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
生成「冷卻水泵」動畫用圖片，共 10 張：
  frame_0 = 停止 (STOP)
  frame_1 ~ frame_9 = 運轉中 (RUN)，馬達冷卻風扇葉片逐格旋轉，
                        並附水流箭頭與運轉指示燈，可循環播放。
"""

import math
import os
from PIL import Image, ImageDraw, ImageFont

W, H = 900, 560
OUT_DIR = "/mnt/user-data/outputs"
os.makedirs(OUT_DIR, exist_ok=True)

# ---------- 顏色定義 ----------
COL_BG          = (255, 255, 255, 255)
COL_BASE        = (60, 60, 65, 255)
COL_MOTOR_STOP  = (90, 95, 100, 255)
COL_MOTOR_RUN   = (55, 70, 120, 255)
COL_MOTOR_SHADE = (35, 40, 45, 255)
COL_PUMP_BODY   = (70, 75, 82, 255)
COL_PUMP_SHADE  = (45, 48, 54, 255)
COL_PIPE        = (170, 175, 180, 255)
COL_FLANGE      = (110, 113, 118, 255)
COL_FIN         = (30, 32, 36, 255)
COL_FAN_STOP    = (140, 143, 148, 255)
COL_FAN_RUN     = (230, 235, 240, 255)
COL_TEXT        = (20, 20, 20, 255)
COL_LED_STOP    = (150, 40, 40, 255)
COL_LED_RUN     = (60, 210, 90, 255)
COL_WATER       = (60, 150, 230, 255)

CJK_FONT = "/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc"
try:
    FONT   = ImageFont.truetype(CJK_FONT, 26)
    FONT_S = ImageFont.truetype(CJK_FONT, 16)
except Exception:
    FONT   = ImageFont.load_default()
    FONT_S = ImageFont.load_default()


def rounded_rect(draw, box, radius, fill):
    draw.rounded_rectangle(box, radius=radius, fill=fill)


def draw_base(draw):
    # 底座
    rounded_rect(draw, (90, 460, 800, 495), 8, COL_BASE)
    for x in (140, 260, 560, 720):
        draw.rectangle((x, 495, x + 30, 510), fill=(40, 40, 44, 255))


def draw_pump_casing(draw):
    # 蝸殼(泵體) - 圓形本體 + 吸入彎管 + 出水法蘭
    cx, cy, r = 225, 330, 105
    draw.ellipse((cx - r, cy - r, cx + r, cy + r), fill=COL_PUMP_BODY, outline=COL_PUMP_SHADE, width=3)
    draw.ellipse((cx - r + 18, cy - r + 18, cx + r - 30, cy + r - 30), fill=COL_PUMP_SHADE)
    draw.ellipse((cx - 22, cy - 22, cx + 22, cy + 22), fill=COL_PUMP_BODY, outline=(20, 20, 22, 255), width=2)

    # 吸入口彎管 (左側，朝左再向下的90度彎頭)
    draw.rectangle((60, cy - 26, cx - r + 10, cy + 26), fill=COL_PIPE, outline=COL_PUMP_SHADE, width=2)
    draw.ellipse((45, cy - 30, 105, cy + 30), fill=COL_PIPE, outline=COL_PUMP_SHADE, width=2)
    # 吸入口法蘭
    draw.rectangle((45, cy - 40, 62, cy + 40), fill=COL_FLANGE, outline=(30, 30, 32, 255), width=2)
    for yy in (cy - 30, cy - 10, cy + 10, cy + 30):
        draw.ellipse((51, yy - 3, 57, yy + 3), fill=(20, 20, 22, 255))

    # 出水口 (泵體下方，垂直向下)
    dx = cx + 10
    draw.rectangle((dx - 22, cy + r - 20, dx + 22, cy + r + 55), fill=COL_PIPE, outline=COL_PUMP_SHADE, width=2)
    draw.rectangle((dx - 32, cy + r + 40, dx + 32, cy + r + 58), fill=COL_FLANGE, outline=(30, 30, 32, 255), width=2)
    return dx, cy + r + 58  # 回傳出水法蘭中心，供水流箭頭使用


def draw_coupling_guard(draw):
    rounded_rect(draw, (300, 300, 365, 360), 6, (80, 83, 88, 255))
    draw.rectangle((300, 300, 365, 360), outline=(30, 30, 32, 255), width=2)


def draw_motor(draw, running):
    body_col = COL_MOTOR_RUN if running else COL_MOTOR_STOP
    x0, x1 = 360, 760
    y0, y1 = 220, 400
    cy = (y0 + y1) // 2

    # 馬達主體（圓柱體：矩形 + 兩端橢圓）
    draw.rectangle((x0, y0, x1, y1), fill=body_col)
    draw.ellipse((x0 - 22, y0, x0 + 22, y1), fill=COL_MOTOR_SHADE)
    draw.ellipse((x1 - 30, y0, x1 + 30, y1), fill=body_col, outline=COL_MOTOR_SHADE, width=3)

    # 散熱鰭片
    fin_col = COL_FIN
    xx = x0 + 40
    while xx < x1 - 60:
        draw.line((xx, y0 + 6, xx, y1 - 6), fill=fin_col, width=5)
        xx += 16

    # 接線盒
    rounded_rect(draw, (500, y0 - 55, 590, y0 + 6), 6, (35, 38, 42, 255))
    draw.rectangle((515, y0 - 45, 575, y0 - 8), outline=(90, 92, 96, 255), width=2)

    # 腳座
    draw.rectangle((410, y1, 460, y1 + 14), fill=(35, 35, 38, 255))
    draw.rectangle((650, y1, 700, y1 + 14), fill=(35, 35, 38, 255))

    return x1, cy  # 風扇蓋中心位置


def draw_fan_cover_and_blades(draw, cx, cy, angle_deg, running):
    r_cover = 62
    cover_col = (50, 52, 56, 255)
    draw.ellipse((cx - r_cover, cy - r_cover, cx + r_cover, cy + r_cover),
                 fill=cover_col, outline=(25, 25, 27, 255), width=3)

    # 風扇蓋通風槽（固定不動，代表外殼）
    for a in range(0, 360, 30):
        rad = math.radians(a)
        x1 = cx + (r_cover - 10) * math.cos(rad)
        y1 = cy + (r_cover - 10) * math.sin(rad)
        x2 = cx + (r_cover - 32) * math.cos(rad)
        y2 = cy + (r_cover - 32) * math.sin(rad)
        draw.line((x1, y1, x2, y2), fill=(80, 82, 86, 255), width=3)

    # 中心軸
    hub_r = 10
    fan_col = COL_FAN_RUN if running else COL_FAN_STOP

    # 扇葉（可旋轉）
    n_blades = 6
    blade_len = 40
    blade_w = 12
    for i in range(n_blades):
        a = math.radians(angle_deg + i * (360 / n_blades))
        bx = cx + blade_len * math.cos(a)
        by = cy + blade_len * math.sin(a)
        perp = a + math.pi / 2
        px = blade_w / 2 * math.cos(perp)
        py = blade_w / 2 * math.sin(perp)
        pts = [
            (cx + px * 0.3, cy + py * 0.3),
            (cx - px * 0.3, cy - py * 0.3),
            (bx - px, by - py),
            (bx + px, by + py),
        ]
        draw.polygon(pts, fill=fan_col, outline=(30, 30, 32, 255))

    draw.ellipse((cx - hub_r, cy - hub_r, cx + hub_r, cy + hub_r), fill=(25, 25, 27, 255))

    # 旋轉動態線（僅運轉時）
    if running:
        for i in range(3):
            a0 = math.radians(angle_deg - 18 - i * 10)
            a1 = math.radians(angle_deg - 4 - i * 10)
            bbox = (cx - (r_cover + 14), cy - (r_cover + 14),
                    cx + (r_cover + 14), cy + (r_cover + 14))
            draw.arc(bbox, math.degrees(a0), math.degrees(a1),
                     fill=(255, 255, 255, 180), width=3)


def draw_status_panel(draw, running, frame_idx):
    # 狀態指示燈 + 文字
    led_col = COL_LED_RUN if running else COL_LED_STOP
    draw.ellipse((60, 40, 90, 70), fill=led_col, outline=(20, 20, 20, 255), width=2)
    label = "RUN 運轉中" if running else "STOP 停止"
    draw.text((100, 42), label, font=FONT, fill=COL_TEXT)
    draw.text((60, 520), f"frame {frame_idx}  (cooling water pump / 冷卻水泵)",
              font=FONT_S, fill=(90, 90, 90, 255))


def draw_water_flow(draw, dx, dy, running, phase):
    # 出水管下方畫水流箭頭，運轉時流動、停止時不畫
    if not running:
        return
    for k in range(3):
        off = (phase * 6 + k * 18) % 54
        y = dy + 14 + off
        draw.polygon(
            [(dx - 14, y), (dx + 14, y), (dx, y + 16)],
            fill=COL_WATER,
        )


def render_frame(idx):
    running = idx != 0
    angle = 0 if idx == 0 else (idx * 40) % 360

    img = Image.new("RGBA", (W, H), COL_BG)
    draw = ImageDraw.Draw(img)

    draw_base(draw)
    dx, dy = draw_pump_casing(draw)
    draw_coupling_guard(draw)
    fan_cx, fan_cy = draw_motor(draw, running)
    draw_fan_cover_and_blades(draw, fan_cx, fan_cy, angle, running)
    draw_water_flow(draw, dx, dy, running, idx)
    draw_status_panel(draw, running, idx)

    path = os.path.join(OUT_DIR, f"pump_frame_{idx}.png")
    img.convert("RGB").save(path, "PNG")
    return path


if __name__ == "__main__":
    paths = [render_frame(i) for i in range(10)]
    for p in paths:
        print(p)
